# NAADAP acquisition SME research notes (raw)

Five research tracks gathered 2026-09-04 with every claim cited by URL and a BLOCKED OR UNREACHABLE section per file. The distilled skill lives in the repo at .claude/skills/gov-acquisition-sme/.

- A-existing-ai-skills.md: prior AI skills, prompts, tools, and papers for federal acquisition
- B-far-framework.md: FAR, DFARS, NMCARS, DoDI 5000.74, consolidation law, document anatomy, thresholds, acronyms
- C-contract-vehicles.md: Navy, DoD, and government-wide vehicle catalog with citations
- D-navair-context.md: challenge listing, NAVAIR/NAWCAD organization, SETR, USN-approved AI, PGIL, PEDDAL
- E-procurement-analytics.md: data sources and APIs, prior art, deterministic offline NLP, vehicle matching
