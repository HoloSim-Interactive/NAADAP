# D — NAVAIR / NAWCAD Acquisition Context for the NAADAP Government-Acquisition-SME Agent

Compiled 2026-09-04. Session web-search budget was exhausted (200/200) partway through; remaining
items were collected with WebFetch/curl and local extraction of downloaded PDFs/DOCs. Everything
below carries its source URL. Confidence notes are inline. Local copies of every downloaded
document are in this same `research/` directory (see "Local artifacts" at the end).

---

## 0. Two headline answers

### PGIL = "Procurement Group Innovation Lab" — CONFIRMED (from the challenge text itself)
The official challenge page and the identical text in repo issue #1 both state, in the Validation
scoring section: *"Correctness is defined as a result being within a group of 20 results
predetermined as correct by the **Procurement Group Innovation Lab (PGIL)** on the validation set."*
- Source (official page): https://centralfloridatechgrove.org/advanced-acquisition-documentation-analysis-prize-challenge/
- Source (repo copy): https://github.com/HoloSim-Interactive/NAADAP/issues/1

Context that makes the name plausible: NAVAIR's headquarters is organized into six groups including
a **"Procurement" group** (Wikipedia, NAVAIR article — "Sustainment, Procurement, Engineering & Cyber
Warfare, Command Operations, Comptroller, Office of General Counsel"), historically AIR-2.0
Contracts. NAVAIR's own market-research notices use the phrase "NAVAIR Procurement Group"
(e.g., Sources Sought N0042125RXXX2, "Electronic Business (eBusiness) Support for the NAVAIR
Procurement Group", NAWCAD Pax River, posted 2025-03-10 —
https://www.cleat.ai/government/contracts/sources-sought-for-navair-procurement-group-electronic-business-ebusiness-support-09v2 ;
SAM.gov copy https://sam.gov/opp/c9874ad910964d6e94a379503e415542/view). A search summary described
the Procurement Group as ">1,000 civilian employees ... majority at Patuxent River, MD, with
contracting activities also in Arlington, VA; Lakehurst, NJ; Orlando, FL; China Lake and Point
Mugu, CA." **No public page for a "Procurement Group Innovation Lab" was found** — it is almost
certainly an internal AIR-2.0 (Procurement Group) cell at NAVAIR HQ/Pax River. Do not confuse it
with the DHS "Procurement Innovation Lab (PIL)" (https://www.dhs.gov/pil), which is unrelated.
Operational implication for the agent: the "correct" set of 20 candidate vehicles per validation
data point is curated by NAVAIR contracting professionals, i.e., ground truth reflects a
contracting officer's judgment of vehicle suitability (scope fit, ordering-office access, ceiling,
competition type), not a purely textual similarity notion.

### PEDDAL — NO SOURCE DEFINES IT (searched hard; candidates listed)
Searched: exact term with/without acronym qualifiers; restricted to navy.mil / navair.navy.mil /
dau.edu / waru.edu / acqnotes.com / dtic.mil / everyspec.com / acquisition.gov; abbreviations.com
("0 definitions for PEDDAL" — https://www.abbreviations.com/PEDDAL); acronymfinder.com (403);
full text of NAVAIRINST 4355.19D (downloaded .doc, 237k chars) and the Naval SETR Handbook v1.0
(downloaded .doc) — **zero hits** for "PEDDAL" or "PEDAL" in either. Also absent from the AcqNotes
SETR deck, SEP Outline 4.1, DoDI 5000.74, DoDI 5000.88 search results, MIL-HDBK-245D.
Only web hits are the surname "Peddal", a Limos Kalinga word, and OCR noise in a 1986 AEFA
helicopter report (https://apps.dtic.mil/sti/tr/pdf/ADA206181.pdf).

Candidate interpretations, ordered by plausibility, all UNVERIFIED:
1. **Client shorthand / mis-recollection of a SETR-adjacent acronym.** In the client's phrase
   "SDD, PDR, CDR, PEDDAL, etc." the first three are (a) a document and (b) two review events.
   Note an important collision: in NAVAIRINST 4355.19D's own acronym list **"SDD" = System
   Development and Demonstration** (the pre-2015 EMD phase), not "Software Design Description".
   The client almost certainly means Software Design Description (DI-IPSC-81435A), but the agent
   should confirm.
2. **A garbled reference to the SETR "products" list.** Every SETR in 4355.19D closes with a
   *Technical Review Summary Report* (attendees, presentations, updated risk assessment with
   mitigation plans, completed RFA forms, minutes, recommendation) plus a completed review
   checklist. No acronym resembling PEDDAL is used for these.
3. **A garbled reference to the pre-EMD review** ("Pre-EMD Review", sometimes written
   "Pre-EMD DR" / "PEMDR") that sits between PDR and CDR in DoD 5000 sequences — phonetically the
   closest real review name ("P-E-D-D-…").
4. **A Product/Program Engineering Data ... deliverable** (e.g., "Product Engineering Design Data
   And Logistics"?) — pure conjecture; no evidence.
Recommendation: keep it as an open question to the Product Manager/client; ask them to spell it
out or point to the document they had in mind. Do not fabricate an expansion in any deliverable.

---

## 1. The prize challenge itself

### 1.1 Official listing
- **Official page (reachable, curl 200):**
  https://centralfloridatechgrove.org/advanced-acquisition-documentation-analysis-prize-challenge/
  Title: "Advanced Acquisition Documentation Analysis Prize Challenge" — banner "NAVAIR/NAWCAD".
  Page assets show NAVAIR seal and NAWCAD logo uploaded July 2026
  (`/wp-content/uploads/2026/07/NAVAIR-Seal-115.png`, `NAWCAD_logo_small.png`).
- Hub pages: https://centralfloridatechgrove.org/active-prize-challenges/ and
  https://centralfloridatechgrove.org/prize-challenge/ (the WebFetch summarizer saw no listings;
  the page-sitemap https://centralfloridatechgrove.org/page-sitemap.xml lists the challenge slug).
- Pre-Screening Questionnaire (Phase 1): https://forms.monday.com/forms/4ecc9715076d893411ae03070f0c655e?r=use1
  (title "GFI Access Pre-Screening Questionnaire"; JS-rendered form).
- **Challenge.gov was sunset 2026-03-30**; federal challenge listings moved to USA.gov Innovation
  (https://www.usa.gov/innovation → https://www.usa.gov/find-active-challenge). The USA.gov
  "select challenges" list does NOT show this challenge (it shows ~12 curated NASA/NIH/CDC/Army
  xTech items). The challenge text still says the portal opens "on USA.gov and the Tech Grove
  Website" and cites Challenge.gov as satisfying competition notice. No SAM.gov, NAVAIR.navy.mil
  or NAWCAD page for the challenge was found (navair.navy.mil blocks; see §6).
- The repo's issue #1 body is a verbatim copy of the page with the title replaced by "NAADAP":
  https://github.com/HoloSim-Interactive/NAADAP/issues/1
- No FAQ, Q&A, or info-session for this challenge was found on the page, on simpletix.com, or
  teamorlando.org (searched). Prior Tech Grove challenges typically had a SimpleTix info session and
  a Team Orlando News write-up; none exists yet for this one as of 2026-09-04.

### 1.2 Dates — the two sections disagree (record both)
| Item | Summary box ("Prize Challenge Dates & Details") | TIMELINE section |
|---|---|---|
| Launch | July 30, 2026 | 7/30/26 release; pre-screening portal open |
| Solution submission deadline | **Sept 22, 2026, 11:59 PM EST** | **10/2/26 11:59 PM EDT** |
| Pre-screening evaluation / semi-finalist notification | — | 10/26/26 (up to 7 semi-finalists) |
| Demo Day deliverables due | — | 11/12/26 11:59 PM ET |
| Final Demo Day | **Nov 9, 2026** | **11/19/26**, in person at Tech Grove |
Client instruction (issue #1, 2026-09-03): plan against the worst case (Sept 22 / Nov 9) until Tech
Grove answers. Note the TIMELINE's "10/26 pre-screening evaluation" wording actually describes the
Phase-2 technical evaluation (selection of semi-finalists), another internal inconsistency. Also
boilerplate leaked from another challenge ("autonomous systems and wildfire response space",
"Team Opportunities Orlando").

### 1.3 Prizes
$150,000 pool: 1st $100,000; 2nd $50,000. Non-cash: exposure to Team Orlando/DoD leaders;
follow-on OTAs (10 USC 4022 prototype / 4021 research), CRADAs, FAR-based contracts; prizes under
10 USC 4025 and 15 USC 3719. Follow-on production possible under 10 USC 4022(f).

### 1.4 Problem statement — VERBATIM (from the official page)
> **Overview.** NAVAIR executes tens of thousands of procurement actions annually. While currently
> leveraging sophisticated tokenization and embedding models for Retrieval-Augmented Generation
> (RAG), there is a critical need to evolve beyond simple document retrieval to unlock the
> analytical power of data cluster analysis by grouping procurement documents based on their
> content. The purpose of this competition is to build a recommender system that can analyze a
> varied population of documents such as statements of work, performance work statements, sources
> sought notices, and open-source information (such as Congressional testimony) and return a
> candidate list of contract vehicles for consolidation.
>
> **Problem Statement.** The challenge aims to develop a fully documented, validated algorithmic
> methodology capable of evaluating, identifying, and recommending common requirements from
> disparate requirements documentation (SOWs, PWSs, CDRLs) as well as open-source information
> (Congressional Testimony, news). The algorithm will automatically produce candidate
> identification and recommendations for strategic vehicles. This includes consolidating similar
> requirements into larger vehicles or identifying new strategic contracting vehicles based on
> future capabilities.
>
> Strategic Contract Vehicles are enterprise scale contracts that allows a large amount of
> requirement owners to procure items/commodities under the same base contract using streamlined
> procedures. While strategic vehicles can encompass vast requirements, they must maintain the
> ability to levy consistent and performance scope requirements to vendors. The benefits of this
> approach include reduced duplication of effort, improved buying power, maximize contract
> ceilings, and improve speed of acquisition.
>
> Today's DoD systems contain sparse databases of information with no systematic way to determine
> common requirements at scale. For example, if VX-XX has a requirement for engineering services on
> the flight line, the requirement owner has to establish their own contract. This is one of many
> locations that needs to buy the same service. A better approach would be to identify similar
> contracting vehicles that can be utilized to fulfill this requirement. In the current ecosystem,
> the process relies on an individual with knowledge of existing systems, requirements, and
> contracting vehicles. In order to streamline acquisition processes, there is a need to
> automatically identify contracts suitable to be used as strategic vehicles.
>
> **Benefits:** The primary benefits include increased buying power, reduction of duplication
> significant process efficiencies, speed of acquisition, and cost savings that directly support
> DoD acquisition reform efforts.

("VX-XX" = an air test and evaluation squadron, e.g., VX-23 / VX-20 / VX-1 at Pax River — the
example is a NAWCAD/Naval Test Wing Atlantic flight-line services requirement.)

### 1.5 Critical Technical Criteria — verbatim
- Deployment Environment: "The solution must be designed for deployment within a U.S.
  Government-owned and operated Cloud environment, accredited for Impact Level 4 (IL4) data."
- System Architecture: "The core analysis and identification methodology must ensure repeatable
  results (produces same top 5 results 95% of the time). The final summarization component (e.g.,
  creating a common visualization) may be stochastic and leverage a Large Language Model (LLM).
  Database schema and ETL process must be provided if database is used."
- Visualization: "Must include a visual representation of the analysis method utilized and results."
- Summary Metrics: "Candidates must provide a summary metric for how they evaluated algorithm performance."
- Dependencies: "Deliverables must be packaged in a Docker container with all external dependencies
  and cannot access external services outside of **USN-approved models or microservices within an
  IL4 environment** (i.e., no external industry-hosted custom models)."

### 1.6 Phases and submission requirements
- **Phase 1 Pre-Screening Questionnaire** — verifies eligibility, org/team info, "Cybersecurity and
  Government Furnished Information access requirements." Approval gates GFI access. (Implication:
  GFI is likely CUI/FOUO procurement data; expect a cyber attestation.)
- **Phase 2 GFI & Solution Submission** — initial technical package: algorithm documentation;
  complete codebase; Docker container; code packages and deployment instructions; database schema
  (if DB used); ETL process documentation (if applicable); visual representation of analysis
  method; visual representation of results; algorithm performance summary metrics; description of
  validation methodology; documentation of external dependencies; required technical and
  supporting documentation. "Code must be fully reproducible, utilize Docker, and be capable of
  operating in an IL4 environment. The submission must not consist solely of a link to a website."
- **Phase 3 Final Demo Day** — up to 7 semifinalists; PowerPoint for judges; live demo; supporting
  technical materials; updated validation documentation; "Presentation including live demo,
  Questions/Answers must be completed within 30 minutes." Each semifinalist receives "a validation
  dataset similar to the test dataset."

### 1.7 Judging criteria — exact
**Robustness of solution: 50%**
- Runtime: 15% if processes a new document set and returns candidates within 30 minutes; 0% otherwise
  ("This is a time requirement, not a validation requirement").
- Replicability: 10% if the container "can be distributed across multiple containers without
  affecting the results. Replication must demonstrably improve performance"; 0% otherwise.
- Compute cost: 15% at 1 core/2 GB; 10% at 4 cores/8 GB; 5% at 8 cores/16 GB; 0% above.
- LLM cost: 10% no LLM; 5% LLM with <50k tokens per retrieval; 0% >50k tokens per retrieval.
**Validation of solution: 50%**
- Initial Technical Evaluation (40 points): "Each data point in the dataset with a correct
  prediction will be granted two percentage points. Correctness is defined as a result being within
  a group of 20 results predetermined as correct by the Procurement Group Innovation Lab (PGIL) on
  the validation set." (⇒ 20 scored data points × 2 = 40.)
- Live Demo Day (10 points): ability "to identify five manually identified candidates from the
  validation set."

### 1.8 Rules / T&Cs highlights
Eligibility: individuals/teams from industry, academia, state/local gov, non-profits; all
individuals ≥18 and U.S. citizens; federal employees and support-service contractors ineligible
(except student-program appointees); no federal funds. NAVAIR/NAWCAD may cancel/modify at will.
Data rights: submissions become federal agency records subject to FOIA (32 CFR 286); protective
markings allowed; participants retain IP and publishing rights but grant the Government and
partners perpetual access/storage; Government agrees not to share with other entities. No Tech
Grove/DoD logos in submissions. About Tech Grove: DoD innovation hub est. 2020 under a Partnership
Intermediary Agreement between NAWCTSD and UCF Research Foundation.

---

## 2. NAVAIR / NAWCAD organization

### 2.1 NAVAIR overview
- HQ: NAS Patuxent River, MD. Commander: VADM John E. Dougherty IV (also now PAE Aviation).
  Wikipedia: https://en.wikipedia.org/wiki/Naval_Air_Systems_Command
- Six HQ groups: Sustainment, Procurement, Engineering & Cyber Warfare, Command Operations,
  Comptroller, Office of General Counsel. Eight competencies: program management, contracts,
  research & engineering, test & evaluation, logistics & industrial operations, corporate
  operations, comptroller, counsel.
- Competency codes (from NAVAIR briefs/SETR docs; not all confirmed by a single reachable page):
  AIR-1.0 Program Management / Assistant Commander for Acquisition
  (https://www.navair.navy.mil/osbp/sites/g/files/jejdrs551/files/2018-12/kurtz_-_air_1.0_panel_brief_20180905_final.pdf);
  **AIR-2.0 Contracts (Procurement Group)**; **AIR-4.0 Research & Engineering** (AIR-4.1 Systems
  Engineering owns the SETR process; AIR-4.0P coordinates Technical Warrant Holders);
  AIR-5.0 Test & Evaluation; AIR-6.0 Logistics & Industrial Operations; AIR-7.0 Corporate
  Operations & Total Force; AIR-10.0 Comptroller; AIR-11.0 Office of Counsel. (AIR-3.0 /
  AIR-8.0 / AIR-9.0 are not current competencies.) NAVAIRINST 4355.19D is signed out by
  "AIR-4.0/5.0/6.0".
- Echelon III: **NAWCAD** (Pax River HQ; Lakehurst NJ; Orlando FL = NAWCTSD; St. Inigoes MD /
  Webster Outlying Field; Naval Test Wing Atlantic), **NAWCWD** (China Lake & Point Mugu CA;
  Naval Test Wing Pacific), **COMFRC** (7 Fleet Readiness Centers + FRC WestPac Atsugi).
- 2021 MD Commerce sheet on NAWCAD: "one of two product centers within NAVAIR"; core product
  areas Air Vehicle, ALRE/Support Equipment, Avionics, Crew Stations, Propulsion & Power,
  Prototyping, Ship/Shore Air Ops, Manned/Unmanned Air Vehicles, T&E Resources; top NAICS
  541330, 336413, 488190, 481219, 541712/541715, 334511, 336411, 336412, 541512, 541519.
  https://commerce.maryland.gov/Documents/BusinessResource/NAWCAD-naval-air-warfare-center-aircraft-division.pdf
- NAWCAD internal group/dept codes seen in the NAWCAD LRAF (FY22 Q4): "Rapid Capability Eng Group /
  NAWCAD WOLF (4.11.x)", "Digital Analytics Infrastructure & Tech Adv (DAiTA) Group (4.13C)",
  "Air Systems Group / Air Vehicle Engineering Dept (4.3)", "Naval Test Wing Atlantic (5.1)".
  https://paxpartnership.org/wp-content/uploads/2024/02/NAWCAD-LRAF-4QTR-FY22_Final_v2.pdf
  NAWCAD Lakehurst Procurement Dept "has unlimited procurement authority for materials, services
  and equipment" (https://www.navair.navy.mil/lakehurst/product/Procurement — blocked to fetch;
  text via search snippet).

### 2.2 PEOs → Portfolio Acquisition Executives (2026 reorg — important currency point)
- Legacy PEOs (Wikipedia https://en.wikipedia.org/wiki/Naval_Air_Systems_Command_Program_Executive_Offices):
  PEO(A) Air ASW, Assault & Special Mission (PMA-207, 261, 264, 271, 274, 275, 276, 290, 299);
  PEO(T) Tactical Aircraft (PMA-205, 209, 213, 226, 231, 234, 251, 257, 259, 265, 272, 273,
  PMW/A-170); PEO(U&W) Unmanned Aviation & Strike Weapons (PMA-201, 202, 208, 242, 260, 262, 263,
  266, 268, 280, 281); PEO(CS) Aviation Common Systems & Commercial Services; PEO(JSF)/F-35.
- **2026-05-11: DON established PAE Aviation, PAE(A)**, led by VADM Dougherty; three deputy PAEs:
  Carrier Strike (RADM Joseph Hornbuckle), Marine Corps Aviation (MajGen David Walsh), Maritime
  ISR & NC3 (RADM Tony Rossi); plus Mission Engineering, Rapid Capability Cell, Disruptive
  Technology Development. Same day: PAE Mission Systems (Jim Day) and PAE Munitions (Paul Mann).
  "PAEs will have direct authority over an entire portfolio of like programs and associated
  technical, contracting and sustainment functions"; mandate to default to commercial solutions,
  MOSA, GPR interfaces, and "faster contracting mechanisms such as OTAs."
  DVIDS (reachable): https://www.dvidshub.net/news/564931/navy-establishes-portfolio-acquisition-executive-aviation
  NAVAIR (blocked): https://www.navair.navy.mil/news/Navy-Establishes-Portfolio-Acquisition-Executive-Aviation/Mon-05112026-0943
  Seapower: https://seapowermagazine.org/navy-advances-acquisition-reform-strategy-appoints-three-new-portfolio-acquisition-executives/
  ("~70% of technical, contracting and sustainment functions will transfer from systems commands
  into these PAEs"; DON now has nine PAEs: RAS, Maritime, Industrial Ops, Marine Corps, SSP,
  Undersea, Aviation, Mission Systems, Munitions.)
  Breaking Defense: https://breakingdefense.com/2026/05/navy-unveils-three-new-paes-for-aviation-mission-systems-munitions/
  ExecutiveGov: https://www.executivegov.com/articles/navy-aviation-mission-systems-munitions-new-paes
  ⇒ For the agent: "NAVAIR" as HCA still exists (NMCARS 5201.601-90 lists NAVAIRSYSCOM as an HCA),
  but requirement ownership is migrating from PEO(x)/PMA-xxx to PAE(A) deputy portfolios; the
  challenge's own text still says "NAVAIR/NAWCAD".

### 2.3 Contracting offices / DoDAACs (where NAVAIR requirements are bought)
Confirmed via NAVAIR OSBP "How to do business" brief (PDF reachable, 2021):
https://www.navair.navy.mil/osbp/sites/g/files/jejdrs551/files/document/%5Bfilename%5D/How%20to%20do%20business%20with%20the%20NAVY%20NAVAIR%20NAWCAD%20NAWCTSD%20NAWCWD.pdf
| UIC/DoDAAC | Activity | Notes |
|---|---|---|
| **N00019** | NAVAIR HQ, Pax River (AIR-2.0 HQ contracts; PEO/PMA platform & weapons buys) | 706 of ~1,200 rows in 2019 command LRAF |
| **N00421** | NAWCAD Patuxent River (NAWCAD Pax contracts dept; issues NAWCAD BAA N00421-25-S-0001, RAPID MAC N00421-19-R-0074, PSMI MAC N0042121R0115, SCI MAC) | 109 rows |
| **N68335** | NAWCAD Lakehurst, NJ (ALRE, support equipment) | 320 rows |
| **N61340** (also UIC N61339) | NAWCTSD Orlando, FL (training systems; Tech Grove's parent) | 99 rows |
| **N68936** | NAWCWD China Lake / Point Mugu | 43 rows |
| N00164 | NSWC Crane (NAVSEA, not NAVAIR — appears once in NAVAIR LRAF as a projected office) | 1 row |
FY20 small-business prime obligations: NAVAIR total $2.861B (HQ $59.5M; NAWCAD $950.2M; FRCs
$11.6M; NAWCWD etc.). NASC OTA (Naval Aviation Systems Consortium, 600+ members, 5-yr OTA awarded
2019, administered by NAWCAD Pax, open to all NAWCs, FRCs and NAVAIR contracting offices):
https://paxpartnership.org/wp-content/uploads/2024/02/NASC_NAWCAD-Industry-Day-5-9-22.pdf
NAVAIR HCA/PEO small-business strategy FY22-23:
https://www.navair.navy.mil/osbp/sites/g/files/jejdrs551/files/document/%5Bfilename%5D/NAVAIR%20HCA%20PEO%20WOLF%20SB%20Strategy%20FY22-23%20Final%20Master%2000SB.pdf (not fetched)

### 2.4 Representative NAVAIR/NAWCAD strategic vehicles (for the recommender's vocabulary)
- **SeaPort-NxG** — DON mandatory-consideration MAC IDIQ for 22 professional-services functional
  areas (NMCARS 5237.102 / Annex 22); task orders competed among ~1,800+ primes; ordered by NAVAIR,
  NAVSEA, NAVWAR etc. https://www.pai-inc.com/contract-vehicles/seaport-nxg ;
  DON brief (blocked): https://www.secnav.navy.mil/smallbusiness/outreach/Documents/Sea-Air-Space-SeaPort-NxG-Brief-May-2019-Final.pdf
- **NAWCAD SCI MAC** — $249M, 5-yr, 40/41 awardees (15 SB), N00421, "support services at multiple
  classification levels ... for all aspects of the acquisition life cycle" across NAVAIR — a
  textbook enterprise "strategic vehicle" for CSS. https://orangeslices.ai/40-awarded-249m-us-navy-navair-platform-and-program-acquisition-life-cycle-support-idiq/ ;
  https://www.washingtontechnology.com/contracts/2025/02/navy-chooses-41-249m-acquisition-lifecycle-contract/403334/
- NAWCAD WOLF RAPID MAC (N00421-19-R-0074), PSMI MAC (N0042121R0115), NAWCAD ASI MAC; NAWCAD
  Mission Systems Software Engineering single-award IDIQ recompete (2026; incumbent American
  Systems, PSC R425) https://www.govconwire.com/articles/navy-nawcad-software-engineering-idiq-recompete
- NAVAIR BOAs (e.g., N00019-20-G-0005) https://www.lawinsider.com/contracts/eaIoFUOl5Jm
- NAWCTSD CSS (Contractor Support Services) N6134019R0061 https://www.dkawins.com/contractor-support-services-css-for-the-naval-air-warfare-center-training-systems-division-nawctsd-orlando-fl/
- Government-wide "Best-in-Class" vehicles (GSA MAS/OASIS+/Alliant 2, NASA SEWP, NIH CIO-SP) —
  relevant because Navy Category Management pushes spend to tiered/BIC solutions (§5.6).
- **2026 NAWCAD RFI "Acquisition Strategy"** (reported on BidBanana, 403 on fetch):
  NAWCAD seeks recommendations for a 5-year services-acquisition plan — four topics: optimizing
  outcome-based contracting, reducing contract-administration workload, accelerating award
  timelines, driving competition; "focused on service acquisition requirements across the NAWCAD
  enterprise." https://bidbanana.thebidlab.com/bid/d1YdnaOytITXOTrbGjxT — this is the same policy
  impulse behind the prize challenge.

### 2.5 Doing business / Small Business / LRAF
- NAVAIR OSBP home: https://www.navair.navy.mil/osbp/ (blocked). Director (2021): Shelby Butler.
  DON OSBP NAVAIR page: https://www.secnav.navy.mil/smallbusiness/pages/navair.aspx (captcha).
- **LRAF**: https://www.navair.navy.mil/LRAF (blocked; Excel download). "Snapshot of what NAVAIR
  is buying from now to ~2 years out ... ~1,200 procurement requirements command-wide"
  (https://www.navair.navy.mil/node/10961, snippet). Field activities also post LRAFs to SAM.gov:
  NAWCAD LRAF FY25 https://sam.gov/opp/f8aab2f29ba34e1a8a3298204911a4f1/view ; FY26 (posted
  2026-02-24, quarterly updates, inactive 2027-10-15) https://sam.gov/workspace/contract/opp/c808cbaa730f4410a84f4ea0adf4a9bf/view ;
  NAWCWD FY25 https://www.navair.navy.mil/nawcwd/sites/g/files/jejdrs601/files/document/%5Bfilename%5D/NAWCWD%20FY25%20LRAF%20JAN%202025.pdf
- **LRAF column layouts (useful as a schema for "contract vehicle" features):**
  - NAVAIR command LRAF (Feb 2019, reachable PDF): Title of Contracting Opportunity | Estimated $
    Threshold | Anticipated Procurement Method (Full and Open, SB Set Aside, 8(a) Sole Source,
    8(a) Competitive, Sole Source…) | Projected Contracting Office (e.g., "N00019 NAVAIRSYSCOM_HQ")
    | Anticipated Solicitation FY/Qtr | Anticipated Award FY/Qtr | Contract Number | Incumbent
    Contractor | Contractor Location | Place of Performance | Requirement Description | NAICS |
    Requirement Organization Command (PEOT/PEOA/PEOU&W…) | PMA/Subcompetency.
    https://www.navair.navy.mil/sites/g/files/jejdrs536/files/2019-04/Command_LRAF_Report_2-11-2019-for-Website.pdf
  - NAWCAD LRAF (FY22 Q4): Group | Department | Dept code (4.x) | Title | Description | Incumbent |
    Contract No. | Period | $ range ($10-50M, $50-100M, >$100M) | Current vehicle type / Anticipated
    vehicle type (e.g., "SA IDIQ", "SeaPort", "MAC") | Solicitation date | Award date | PSC (R425,
    J059…) | NAICS | Competition (Unrestricted / set-aside).
  ⇒ These are exactly the attributes a "strategic vehicle" recommender needs to reason over
  (vehicle type, ordering office, ceiling band, PSC/NAICS, competition type).
- Sources Sought / Industry Days: NAVAIR documents sources-sought responses on the Small Business
  Coordination Record (DD 2579 via the SBCR application, NMCARS 5219.201); posts pre-solicitation
  and industry-day notices on SAM.gov; NAWCAD Lakehurst holds an annual Small Business Roundtable
  Industry Day (https://www.navair.navy.mil/news/Annual-Industry-Day-brings-NAWCAD-Lakehurst-and-small-businesses-closer-together/Wed-06182025).
  NAWCTSD runs a virtual PALT meeting (https://www.navair.navy.mil/nawctsd/PALT).

---

## 3. Navy acquisition process & documentation

### 3.1 NAVAIRINST 4355.19 (SETR) — revision status
- **4355.19D** (2008; supersedes 4355.19C of 10 Apr 06; signed AIR-4.0/5.0/6.0) — full text
  obtained (.doc): https://www.acqnotes.com/Attachments/NAVAIR%20Instruction%204355.19D%20Systems%20Engineering%20Technical%20Review%20Process.doc
  EverySpec listing: https://everyspec.com/USN/NAVAIR/4355x19D_13732/
- **4355.19E** (dated ~Feb 2015; "supersedes and cancels 4355.19D") is the **latest public
  revision found**; hosted at DAU/WARU (403 to us):
  https://www.waru.edu/sites/default/files/Migrated/CopDocuments/NAVAIRINST%204355.19E%20SE%20Technical%20Review%20Process%2020150206.pdf
  and https://www.dau.edu/navairinst-435519e-se-technical-review-process (redirects to waru.edu, 403).
  Companion: "SETR Process Handbook Version 1.0, prepared by AIR-4.1" (2015):
  https://www.waru.edu/sites/default/files/Migrated/CopDocuments/SETR%20Process%20Handbook%20v1.0%2020150206.pdf (403).
  No 4355.19F was found. NOTE: DAU's site now redirects to **waru.edu** ("Warfighting Acquisition
  University"?) — the rebrand is recent; treat dau.edu links as aliases.
- Navy-wide equivalent: "Naval Systems Engineering Technical Review Handbook v1.0" (NAVSEA/NAVAIR/
  NAVSUP/NAVFAC/SPAWAR/MCSC; applies to SYSCOMs *except NAVAIR*, which uses 4355.19) — obtained (.doc):
  https://www.acqnotes.com/Attachments/Systems%20Engineering%20Technical%20Review%20Process%20Handbook%20v1.doc
- AcqNotes summaries: https://www.acqnotes.com/acqnote/careerfields/systems-engineering-technical-review-process ;
  https://www.acqnotes.com/acqNote/major-reviews-overview ; NAWCTSD SETR deck (INCOSE Orlando, 403):
  https://www.incose.org/docs/default-source/orlando/nawctsd-setr-process.pdf?sfvrsn=8c58ac6_6 ;
  "SETR: Navy's Acquisition and Development Process and Software Lessons Learned" deck (obtained):
  https://www.acqnotes.com/Attachments/SETR%20Navy%E2%80%99s%20Acquisition%20and%20Development%20Process%20and%20Software%20Lessons%20Learned.pdf
- ASN(RD&A) "Software Criteria and Guidance for SETRs" supplement (captcha):
  https://www.secnav.navy.mil/rda/OneSource/Documents/Program%20Assistance%20and%20Tools/Handbooks,%20Guides%20and%20Reports/Page%205/supplementtoguidebook.pdf

### 3.2 SETR review list — verbatim from NAVAIRINST 4355.19D para 4.d
"The following essential SETRs should be conducted, as applicable, on all ACAT programs:
(1) Initial Technical Review (ITR); (2) Alternative Systems Review (ASR); (3) System Requirements
Review I (SRR-I); (4) System Requirements Review II (SRR-II); (5) System Functional Review (SFR);
(6) Software Specification Review (SSR); (7) Preliminary Design Review (PDR); (8) Critical Design
Review (CDR); (9) Integration Readiness Review (IRR); (10) Test Readiness Review (TRR); (11) Flight
Readiness Review (FRR) (for airborne systems); (12) System Verification Review/Production Readiness
Review (SVR/PRR); (13) Physical Configuration Audit (PCA); and, (14) In-Service Review (ISR).
At a minimum, SRRs, PDRs, CDRs and SVRs should be conducted on all non-ACAT acquisition programs.
For acquisition programs with multiple software increments, the program should conduct a SSR, CDR,
and IRR for each increment. In addition to SETRs, programs conduct Integrated Baseline Reviews
(IBRs) and Operational Test Readiness Reviews (OTRRs)..." Also Technology Readiness Assessments (TRA).
Baselines: SRR-I/II → Performance baseline; SFR → Functional baseline; PDR → Allocated baseline;
CDR → Initial Product baseline; SVR/FCA → verifies product baseline; PCA → final product baseline.

### 3.3 Entrance/exit criteria and artifacts (from 4355.19D enclosure (1) and the Navy handbook)
- Principles: SETRs are "event driven (vice schedule driven), ... conducted when the system under
  development meets the review entrance criteria **as documented in the SEP**, and include
  participation by SMEs who are independent of the program." "These reviews are not the place for
  problem solving, but to verify that problem solving has been accomplished." Chaired by an
  independent Technical Review Board (TRB) chair from AIR-4.1; Technical Warrant Holders adjudicate
  RFAs; review checklists "may be tailored ... at the discretion of the TRB Chairperson"; agenda to
  participants 30 days prior.
- Generic **products of every SETR**: Technical Review Summary Report with (a) attendee list,
  (b) final presentations, (c) updated risk assessment with mitigation plans, (d) completed
  Request for Action (RFA) forms, (e) minutes, (f) recommendation to PMA; plus the completed
  review checklist. A review "is considered complete when all draft RFAs are signed off, and an
  acceptable level of program risk is ascertained"; APMSE then prepares a closure letter for the
  TRB chair. The Navy handbook adds a Technical Review Action Plan (TRAP) and RFA/RFI forms.
- Typical entrance criteria/artifacts cited in 4355.19D by review (representative, not exhaustive):
  - ITR/ASR: ICD/AoA products, draft performance spec, preliminary TRA, SEP, MOEs/MOPs/KPPs,
    draft TEMP, SOO/SOW for next phase, Software Development Plan (SDP).
  - SRR-I/II: system requirements (SRS/SDS), requirements trace to capability documents,
    Interface Design Documents; ICDs achieved by PDR-II.
  - SFR: functional baseline; Functional Requirements Trace and Completeness; Software/System
    Architecture; Measurement Data; Allocated Baselines; Sufficiency of Design; Test & Cert reqs.
  - SSR: software requirements baseline (SwRS/SRD), CDRLs, software development strategy/process,
    requirements analysis & allocation methodology, system specification tree, IMS with software
    milestones.
  - PDR: "top level Software Design Description developed during preliminary design"; ICDs;
    allocated baseline; incremental sub-system PDRs allowed.
  - CDR: "Detailed Software Design Description to be completed by CDR"; initial product baseline;
    completed test plan; draft test procedures; traceability from design documentation to
    requirements; updates to SRR/SFR/SSR products.
  - TRR/IRR/FRR: test procedures, integration readiness, safety/flight clearance certificates.
  - SVR/PRR/PCA/ISR: verified performance vs CPD, production planning, as-built configuration,
    in-service performance/sustainment.
- DoD-level requirement: DoDI 5000.88 "Engineering of Defense Systems" lists required technical
  reviews; SEP Outline v4.1 (May 2023, OUSD(R&E)) §3.2 mandates a "Technical Review and Audit
  Details" table per review (chair, entry criteria, tailored objective **exit criteria**, expected
  products) and an Appendix E "Digital Engineering Implementation Plan".
  https://ac.cto.mil/wp-content/uploads/2023/05/SEP-Outline-4.1.pdf (obtained);
  DoDI 5000.88 https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500088p.PDF (403).
- ACRONYM TRAP: in 4355.19D, **SDD = System Development and Demonstration**; SDP = Software
  Development Plan; SRD = Software Requirements Description; SwRS = Software Requirements Spec;
  SEMP vs SEP distinction; TEMP.

### 3.4 DoDI 5000.02 Adaptive Acquisition Framework
Six pathways (DoDI 5000.02 "Operation of the Adaptive Acquisition Framework", Jan 2020 w/ changes;
now styled "DoW Instruction"): Urgent Capability Acquisition (DoDI 5000.81); Middle Tier of
Acquisition (5000.80); Major Capability Acquisition (5000.85); **Software Acquisition (5000.87)**;
Defense Business Systems (5000.75); **Acquisition of Services (5000.74)**.
https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500002p.PDF (403 to us);
https://aaf.waru.edu/aaf/aaf-pathways/ (403); MITRE AiDA (password-protected).
DoDI 5000.74 (Jan 10, 2020; obtained) S-CATs by total value: S-CAT I ≥$1B (or >$300M/yr) — SAE/CAE;
S-CAT II $250M–1B — SAE/CAE; S-CAT III $100–250M — Component Senior Services Manager (SSM);
S-CAT IV $10–100M — SSM; S-CAT V SAT–$10M — SSM. Establishes portfolio/category alignment with the
government-wide category management framework and the Services Acquisition Workshop (SAW).
NMCARS 5237.192 requires SAW for services ≥$500M total or ≥$250M/yr.
⇒ Relevance: consolidating requirements into a strategic vehicle changes the S-CAT tier and the
approval authority (DASN(P) at ≥$250M per NMCARS 5207.103(j)); NMCARS 5207.107-2/-3 require
consolidation/bundling determinations (approved by DASN(P) or the HCA depending on STRAP level).

### 3.5 DIDs commonly on NAVAIR CDRLs (DD Form 1423)
- DI-MGMT-81861 (→ 81861A/B) Integrated Program Management Report / IPMDAR (EVM, ANSI/EIA-748)
  https://everyspec.com/DATA-ITEM-DESC-DIDs/DI-MGMT/DI-MGMT-81861_42561/ ; Navy CEVM sample IPMR
  CDRL https://www.secnav.navy.mil/rda/OneSource/Documents/CEVM/Tools%20and%20Examples/CDRL%20Examples/SampleNavyCEVMIPMRCDRL20120822Part1.pdf (captcha)
- DI-SESS-81785 / 81785A **Systems Engineering Management Plan (SEMP)** (contractor's plan;
  supersedes DI-MGMT-81024) — note the government's SEP is not a DID deliverable.
- DI-MISC-80508 (→ 80508B) Technical Report – Study/Services (the workhorse "report" DID).
- DI-IPSC-81435A Software Design Description (SDD); DI-IPSC-81433A Software Requirements Spec;
  DI-IPSC-81427A Software Development Plan; DI-IPSC-81438A Software Test Plan; DI-IPSC-81441A
  Software Test Report; DI-IPSC-81436A Interface Design Description; DI-IPSC-81448A Software
  Version Description; DI-IPSC-81443A Software User Manual (the MIL-STD-498 family, still widely
  cited on NAVAIR software CDRLs). EverySpec index https://everyspec.com/DATA-ITEM-DESC-DIDs/
- DI-MGMT-80368A Status Report; DI-MGMT-81466A Contract Performance Report (legacy); DI-ADMN-81249A
  Conference Agenda/Minutes; DI-MGMT-81650 IMS; DI-SAFT-80102B Safety Assessment Report.
- DD 1423 instructions: https://www.esd.whs.mil/Portals/54/Documents/DD/forms/dd/dd1423.pdf ;
  NAVAIR AMS Suite CDRL tool (DAU tools page): https://www.waru.edu/tools/navair-acquisition-management-system-ams-suite
  ("centralized data repository for organizing and maintaining DD 1423 CDRL forms").

### 3.6 NAVAIR Systems Engineering Plan / MBSE / Digital Engineering
- NAVAIR Systems Engineering Transformation (SET): adopted **SysML** and **Cameo Systems Modeler**;
  Digital System Models (DSMs) as the Authoritative Source of Truth; the Navy **Integrated
  Modeling Environment (IME)**, hosted on DoD HPCMP, is the enterprise IT service for systems
  modeling (6,000+ users, ~30% YoY growth) with access for non-CAC holders (industry).
  DAU blog: https://www.dau.edu/library/defense-atl/blog/NAVAIR--Systems-Engineering-Transformation
  (→ https://www.waru.edu/library/defense-atl/blog/NAVAIR--Systems-Engineering-Transformation, 403);
  Navy DE update (Chris Kent, Nov 2022): https://www.waru.edu/sites/default/files/Migrate/EventAttachments/745/DAU%20Lets%20Get%20Digital%20%20Chris%20Kent%20Navy%20DE%20Update%20%20%2020221117.pdf ;
  DTIC "Transforming SE through MBSE" https://apps.dtic.mil/sti/pdfs/AD1073187.pdf ;
  MIT News on NAVAIR SET training https://news.mit.edu/2018/mit-online-course-model-based-design-transforming-us-dod-navair-acquisitions-0806 ;
  APAN NAVAIR MBSE CoP https://community.apan.org/wg/navair-set/navair-mbse-community-of-practice/
- SEP content requirements come from DoD SEP Outline v4.1 (§3.1 technical schedule, §3.2 technical
  reviews table, §3.4 DE/MBSE approach, Appendix E DE Implementation Plan). SETR entrance criteria
  are program-specific and live in the SEP.

### 3.7 Public SOW/PWS/CDRL exemplars the client pointed to
- NSWC Dahlgren "Leading Edge" page (client-cited; navsea.navy.mil 403 to us):
  https://www.navsea.navy.mil/Home/Warfare-Centers/NSWC-Dahlgren/Resources/Leading-Edge/I-I-Leading-Edge/Washington02/
- FOIA-released NAVAIR contracts with SOW/CDRLs (navair.navy.mil, blocked): e.g.
  https://www.navair.navy.mil/foia/sites/g/files/jejdrs566/files/2019-09/Final%20Contract%20and%20Mods%201-52.pdf ,
  NAWCWD N68936-09-D-0023 https://www.navair.navy.mil/nawcwd/sites/g/files/jejdrs601/files/2018-12/n68936-09-d-0023.pdf
- Reachable solicitation packages with CDRL exhibits: NAWCAD RAPID MAC amendment
  https://imlive.s3.amazonaws.com/Federal%20Government/ID16060893438081203869328321323930895279/N00421-19-R-0074%20RAPID%20MAC%20Amendment%200002.pdf ;
  PSMI MAC https://imlive.s3.amazonaws.com/Federal%20Government/ID31817116017030136473886500883981839939/N0042121R0115%20%20-%20PSMI%20MAC%20FINAL%20.pdf ;
  CDRL package examples https://imlive.s3.amazonaws.com/Federal%20Government/ID112914141035283784220653749584968763150/Exhibit_A_CDRL_Package.pdf
- ONR SOW template (.docx, obtained): https://www.onr.navy.mil/assets/2023-02/statement-work-template.docx
- MIL-HDBK-245D "Preparation of Statement of Work" (Apr 1996; obtained via search) — canonical
  SOW structure (1 Scope, 2 Applicable Documents, 3 Requirements) that NAVAIR SOWs still follow.

---

## 4. Navy IT / AI environment relevant to "IL4, USN-approved models/microservices"

### 4.1 Impact levels (DoD Cloud Computing SRG)
- IL4 = CUI, non-CUI, non-critical mission info, non-NSS; FedRAMP Moderate+ baseline (FedRAMP High
  PA accepted for IL4 without extra C/CE assessment); CSP personnel must be US persons.
  IL5 = higher-sensitivity CUI, mission-critical, unclassified NSS; physical/logical separation
  from non-federal tenants; US citizens. IL6 = SECRET.
  https://learn.microsoft.com/en-us/azure/compliance/offerings/offering-dod-il4 ;
  https://coalfire.com/the-coalfire-blog/dod-cloud-computing-impact-levels-4-5 ;
  SRG docs https://public.cyber.mil/dccs/dccs-documents/
- "U.S. Government-owned and operated Cloud ... accredited for IL4" — the phrase "government-owned
  and operated" excludes vendor-hosted SaaS; practically it means a DON tenant in Azure Government
  (Flank Speed Azure), AWS GovCloud under a DON ATO, or an on-prem/HPCMP environment.

### 4.2 DON cloud/data platforms
- **Flank Speed** — DON's PEO Digital IL5 M365 + Azure Government environment (680k+ users; CAC
  auth; full Zero Trust target compliance Oct 2024). "Flank Speed Azure for Business" = IaaS/PaaS
  hosting for Navy applications inside the accredited tenant (opened 2023). Flank Speed IL5 GitHub
  service and IL6 Azure tenant ATO'd Aug 2024 (Neptune CMO/PEO Digital; supports RAISE).
  https://www.logtool.com/toolbox/navy-flank-speed ;
  https://www.navy.mil/Press-Office/News-Stories/Article/3432370/department-of-the-navy-opens-flank-speed-azure-for-business/ (403);
  https://www.executivegov.com/articles/navy-departments-2-flank-speed-cloud-computing-capabilities-get-ato-approval ;
  https://www.peodigital.navy.mil/News/Article/3861151/... (403); https://www.doncio.navy.mil/chips/ArticleDetails.aspx?ID=17894 (blocked)
- **Naval Identity Services (NIS)** — DON's enterprise ICAM (Azure AD/Entra-based) used by Flank
  Speed and Flank Speed Azure apps for CAC/PIV federation (from Flank Speed materials; not
  separately fetched).
- **Jupiter** — DON Enterprise Data & Analytics Environment (launched Apr 2020), a DON "community
  space" on OSD's **Advana** (jupiter.data.mil); data catalog, on-demand compute, BI/data science
  tooling (Databricks/Qlik-class). https://www.doncio.navy.mil/mobile/ContentView.aspx?ID=13804&TypeID=21 (blocked);
  https://fedscoop.com/ai-task-force-for-navy-surface-fleet-devising-comprehensive-data-catalog/ ;
  Advana P2P procurement analytics (holds FPDS/EDA/PIEE contract data): https://www.acq.osd.mil/asda/dpc/ce/p2p/docs/training-presentations/2024/p2p_2024-procurement_analytics_data_in_advana_part_i_508_Oct25.pdf (connection failed)
- NAVAIR data/analytics: the NAWCAD **DAiTA (Digital Analytics Infrastructure & Tech Advancement)
  Group, 4.13** appears in the NAWCAD LRAF — the likely NAWCAD home for data-platform work;
  NAVAIR's Procurement Group runs eBusiness/PIEE-integrated systems (Sources Sought above).
  IME on HPCMP for MBSE models.

### 4.3 USN-approved AI/LLM services — what "USN-approved models or microservices" plausibly means
- **GenAI.mil** — DoW enterprise generative-AI platform (launched 2025-12-09; IL5, CUI-authorized;
  chat, file upload, RAG, web grounding). Models: Google Gemini for Government first; xAI Grok for
  Government added; OpenAI ChatGPT added Feb 2026; Anthropic Claude announced as forthcoming.
  **DON mandate: 2026-01-28 memo by ASN(RDA), PMD and DON CIO designating GenAI.mil the DON
  Enterprise IT Service for generative AI; all DON orgs to transition by 2026-04-30 and to report
  all current/planned genAI capabilities to the DON CIO GenAI Task Force within 15 days.**
  https://www.executivegov.com/articles/navy-genai-mil-enterprise-it-service-cui-il5 ;
  https://defensescoop.com/2026/02/02/military-branches-genai-mil-enterprise-ai-adoption/ ;
  https://www.airandspaceforces.com/pentagon-adds-chatgpt-official-ai-tool-set/
- **DON GPT / DoN GPT** — DON-built genAI on Flank Speed (IL5), led by Jacob Glassman (ASN RDA
  office) with NRL; alpha 2025, beta mid-2025; demonstrated drafting an acquisition strategy.
  https://defensescoop.com/2025/06/11/navy-don-gpt-prototype-genai-deploy-at-scale/ ;
  https://www.potomacofficersclub.com/articles/navy-genai-dongpt-ai-rapid-capability-cell-govcon/
  (Status after the GenAI.mil mandate unclear — treat as legacy/transitioning.)
- **DON CIO interim guardrails on GenAI/LLM** (Sept 2023): https://www.doncio.navy.mil/ContentView.aspx?ID=16442 (blocked);
  summarized at NPS libguide https://libguides.nps.edu/gen-ai/guidance and DON CIO "Accelerating
  AI adoption" https://www.doncio.navy.mil/ContentView.aspx?id=20459 (blocked).
- Other services (for comparison): Air Force **NIPRGPT** (AFRL, NIPRNet, 700k users) sunset
  2025-12-31 in favor of GenAI.mil https://defensescoop.com/2025/12/18/air-force-sunsetting-niprgpt-generative-ai-platform/ ;
  Army **CamoGPT** retained as R&D/agentic-AI platform alongside the Army Enterprise LLM Workspace
  (23+ approved commercial models) https://defensescoop.com/2026/01/27/army-camogpt-dod-genai-mil/ .
- **Cloud-provider models with DoD IL4/IL5 PAs** (what a DON mission owner could stand up inside
  its own IL4/IL5 tenant):
  - Azure OpenAI Service authorized as a service within Azure Government's DoD IL4 and IL5 PAs
    (2024; later IL6): https://techcommunity.microsoft.com/blog/publicsectorblog/azure-openai-now-authorized-as-a-service-at-dod-il4-and-il5/4231171 ;
    https://devblogs.microsoft.com/azuregov/azure-openai-authorization/
  - Amazon Bedrock in AWS GovCloud: FedRAMP High + DoD CC SRG IL4/IL5 for Anthropic Claude and Meta
    Llama (June 2025), later OpenAI GPT/GPT-OSS, NVIDIA Nemotron (June 2026), Mistral, Cohere,
    Amazon Titan embeddings, xAI Grok — plus Agents, Guardrails, Knowledge Bases.
    https://aws.amazon.com/blogs/publicsector/accelerating-government-innovation-amazon-bedrock-models-get-fedramp-high-and-dod-il-4-5-approval-in-aws-govcloud-us/ ;
    https://aws.amazon.com/compliance/services-in-scope/FedRAMP/amazon-bedrock-models/ (page dated 2026-08-25);
    https://aws.amazon.com/about-aws/whats-new/2026/06/addl-bedrock-model-fedramp-il-5-govcloud/
  - Databricks IL5 on AWS GovCloud https://www.databricks.com/company/newsroom/press-releases/databricks-achieves-authorization-dod-il5-aws-govcloud
- **Interpretation for the agent:** "USN-approved models or microservices within an IL4
  environment" ⇒ (a) GenAI.mil APIs/models (the DON-mandated enterprise service), (b) DON-ATO'd
  model endpoints inside Flank Speed Azure (Azure OpenAI in Azure Government) or a DON AWS GovCloud
  tenant (Bedrock), (c) locally packaged open-weight models running inside the container, or
  (d) no LLM at all. Explicitly excluded: calls to commercial SaaS endpoints (api.openai.com,
  Anthropic API, Hugging Face inference, etc.). The scoring rubric rewards (d)/(c).
  NIPRGPT is gone; "NIPRGPT-compatible" is not a meaningful target.
- NAVAIR/NAWCAD AI signals: NAVAIR SBIR N25.2-089 "Virtual Agent for Data Fusion and
  Understanding" https://navysbir.com/n25_2/N252-089.htm ; N25.1-019 neuro-symbolic AI agents for
  ATO https://navysbir.us/n25_1/N251-019.htm ; PAE(A) Rapid Capability Cell (2026). Related OSD
  research: AIRC/Stevens-VT "NLP Recognition and Categorization of Acquisition Text and Documents"
  (AIRC-2026-TR-005, Apr 2026 — ingestion, keyword/context ID, summarization, **clustering** and
  visualization of NDAA/DFARS text for DPCAP) — useful prior art to cite.
  (Local copy: webfetch-1788543271565-bm3p4t.pdf.) Also NPS ARS 2025 papers "AcquireAI — AI
  platform for Acquisition Management" (SYM-AM-25-341) and "Leveraging Generative AI for Validating
  the Quality of..." (SYM-AM-25-316) (local copies f3vzij / kei1pr).

---

## 5. Navy procurement document conventions and services governance

### 5.1 SOW / PWS / CDRL conventions
- SOW structure per MIL-HDBK-245D (Scope / Applicable Documents / Requirements; tasks in §3 with
  CDRL cross-references); PWS (performance-based, FAR 37.6) with Performance Requirements Summary
  and QASP; SOO for solicitations. NAVAIR services solicitations typically carry Section C
  SOW/PWS, Exhibit A CDRLs (DD 1423-1, one per data item, referencing SOW paragraph), Section L/M,
  and NMCARS/DFARS clauses. ONR SOW template as a Navy exemplar.
- NAVAIR data management: NAVAIR AMS Suite CDRL tool; DD 1423 Item 4 = DID number, Item 5 =
  SOW paragraph reference.

### 5.2 NMCARS — key parts for the recommender's domain (all reachable on acquisition.gov)
- Part 5201 https://www.acquisition.gov/nmcars/part-5201-federal-acquisition-regulations-system ;
  5201.601-90 DASN(P) plenary contracting authority; 11 HCAs (incl. NAVAIRSYSCOM).
- Part 5207 Acquisition Planning https://www.acquisition.gov/nmcars/part-5207-acquisition-planning :
  STRAP formats (Annexes 17-20), MOPAS-S (Annex 21); 5207.103(j) approval — DASN(P) ≥$250M,
  HCA/PEO below; Navy SSM for services; STRAPs emailed to RDAJ&As.fct@navy.mil;
  5207.107-2 consolidation determinations (DASN(P)/HCA), 5207.107-3 bundling (via DASN(P)).
- Part 5237 Service Contracting https://www.acquisition.gov/nmcars/part-5237-service-contracting :
  **5237.102 — "consideration of using SeaPort to satisfy the requirements for the functional areas
  shown in Annex 22 is mandatory"** except FAR 6.302-1..-7 actions, below-SAT, 8(a) set-asides,
  Part 12 commercial, Part 13 SAP; 5237.103 D&F to DASN(P) if not using SeaPort;
  5237.5 management oversight (MOPAS-S <$50M/<$25M-yr; PSTRAP-M/ISTRAP-M above);
  5237.192 Services Acquisition Workshop ≥$500M/$250M-yr.
- Part 5219 Small Business https://www.acquisition.gov/nmcars/part-5219-small-business-programs :
  DD 2579 via SBCR application (except SeaPort); SBA PCR 5-business-day review; OSBP appeal route.
- DFARS 207.170 consolidation thresholds ($2M) and FAR 7.107 bundling analysis apply on top.

### 5.3 Sources Sought / Industry Days / Set-asides
See §2.5. Rule of Two (FAR 19.502-2) drives set-aside decisions; NAVAIR documents market research
outcomes on DD 2579; NAWCAD sources-sought notices (e.g., 16 responses on the Mission Systems
software IDIQ) feed competition-type decisions recorded in the LRAF "Anticipated Procurement Method".

### 5.4 Contracted / Contractor Support Services (CSS) governance
- DoDI 1100.22 "Policy and Procedures for Determining Workforce Mix" (Apr 12, 2010, Ch.1) —
  inherently governmental / closely-associated functions test that bounds what CSS may do
  https://www.esd.whs.mil/portals/54/documents/dd/issuances/dodi/110022p.pdf (403); DFARS 207.5.
- DoDI 5000.74 Defense Acquisition of Services (§3.4); DoD Handbook of Contract Function
  Checklists for Services (May 2018, hosted by DASN(P)) https://www.secnav.navy.mil/rda/DASN-P/Shared%20Documents/Services%20Acquisition/DoD%20Handbook%20of%20Contract%20Function%20Checklists%20for%20Services%20Acquisitions.pdf (captcha).
- SECNAVINST 4200.36B (10 Jun 2019) — Navy contractor labor relations (not CSS governance per se)
  https://www.secnav.navy.mil/doni/Directives/04000%20Logistical%20Support%20and%20Services/04-200%20Contracting%20Services/4200.36B.pdf (captcha).
- In NAVAIR usage "CSS" = "Contractor Support Services" (e.g., NAWCTSD CSS N6134019R0061; NAWCAD
  SCI MAC). The Navy's enterprise answer to CSS proliferation is SeaPort-NxG + HCA-level MACs;
  the NAWCAD 2026 Acquisition-Strategy RFI and this prize challenge are the next step.

### 5.5 Navy Senior Services Manager / Contractual Services Working Group
- DON SSM (within DASN(P)) "responsible for the planning, strategic sourcing, management, and
  oversight of services acquisitions for the DON" (DoDI 5000.74 / NMCARS 5237). DON Contractual
  Services Working Group charter: https://www.secnav.navy.mil/rda/DASN-P/Shared%20Documents/Services%20Acquisition/CSWG%20Charter.pdf (captcha).

### 5.6 Navy Category Management / strategic sourcing
- **DON Category Management Program Office** (under DASN(P), OASN(RDA)): "category management is a
  strategic approach to buying common goods and services as an organized enterprise ... using
  existing contract solutions"; manages/reviews DON **tier-rated contracts** (OMB tiers 0–3;
  Tier 3 = Best-in-Class), updated monthly. https://www.secnav.navy.mil/rda/DASN-P/CMP/Pages/default.aspx (captcha);
  document library https://www.secnav.navy.mil/rda/DASN-P/Shared%20Documents/Forms/All%20Documents.aspx?RootFolder=%2Frda%2FDASN-P%2FShared+Documents%2FServices+Acquisition%2FCategory+Management
- DASN(P): principal procurement adviser to ASN(RDA), Competition Advocate General, DON
  Acquisition Ombudsman; incumbent (Apr 2026) Michael Brown. https://en.wikipedia.org/wiki/Deputy_Assistant_Secretary_of_the_Navy_(Acquisition_and_Procurement)
- OMB M-19-13 "Category Management: Making Smarter Use of Common Contract Solutions and
  Practices" (Mar 20, 2019) and GSA Government-wide Category/PSC taxonomy (10 categories incl.
  Professional Services, IT, Facilities) — the PSC→category mapping is a ready-made feature for
  clustering SOWs (local copies ll7sh8 / x8ik4y). BIC solutions list (i5jce2).
- ⇒ For the recommender: a "strategic vehicle" recommendation should be expressible in Navy CM
  vocabulary — Spend Under Management tier, category/PSC, mandatory-consideration status
  (SeaPort), HCA ownership, ordering-office eligibility.

---

## 6. BLOCKED OR UNREACHABLE (exact URL → result)
Legend: WF = WebFetch; curl = direct curl with browser UA through the session proxy.

**navair.navy.mil — every page 403 (F5/WAF "Request Rejected", 4,551-byte block page); PDFs under
/sites/g/files/ DO download (200):**
- https://www.navair.navy.mil/LRAF — curl 403; WF 403
- https://www.navair.navy.mil/osbp/ — curl 403; WF 403
- https://www.navair.navy.mil/nawcad/ — WF 403
- https://www.navair.navy.mil/nawcad/whatwedo — curl 403; WF 403
- https://www.navair.navy.mil/nawctsd/DoingBusiness — curl 403; WF 403
- https://www.navair.navy.mil/organization-landing-page — curl 403
- https://www.navair.navy.mil/acronyms — curl 403
- https://www.navair.navy.mil/node/22811 (NAWCAD Innovation Challenge) — curl 403
- https://www.navair.navy.mil/node/10961 (LRAF article) — WF 403
- https://www.navair.navy.mil/nawcad/AIRWorks — curl 403
- https://www.navair.navy.mil/news/Navy-Establishes-Portfolio-Acquisition-Executive-Aviation/Mon-05112026-0943 — curl 403; WF 403
- (OK) https://www.navair.navy.mil/osbp/sites/g/files/jejdrs551/files/document/%5Bfilename%5D/How%20to%20do%20business%20with%20the%20NAVY%20NAVAIR%20NAWCAD%20NAWCTSD%20NAWCWD.pdf — curl 200 (PDF)
- (OK) https://www.navair.navy.mil/sites/g/files/jejdrs536/files/2019-04/Command_LRAF_Report_2-11-2019-for-Website.pdf — curl 200 (PDF)

**secnav.navy.mil — HTTP 200 but returns a JavaScript captcha interstitial ("Please enable
JavaScript ... What code is in the image?"); WF reports "Request Rejected":**
- https://www.secnav.navy.mil/smallbusiness/pages/navair.aspx
- https://www.secnav.navy.mil/rda/DASN-P/CMP/Pages/default.aspx
- https://www.secnav.navy.mil/rda/DASN-P/Shared%20Documents/Services%20Acquisition/CSWG%20Charter.pdf
- https://www.secnav.navy.mil/doni/Directives/04000%20Logistical%20Support%20and%20Services/04-200%20Contracting%20Services/4200.36B.pdf
- https://www.secnav.navy.mil/rda/OneSource/Documents/Program%20Assistance%20and%20Tools/Handbooks,%20Guides%20and%20Reports/Page%205/supplementtoguidebook.pdf
- https://www.secnav.navy.mil/rda/OneSource/Documents/CEVM/Tools%20and%20Examples/CDRL%20Examples/SampleNavyCEVMIPMRCDRL20120822Part1.pdf
- https://www.secnav.navy.mil/smallbusiness/outreach/Documents/Sea-Air-Space-SeaPort-NxG-Brief-May-2019-Final.pdf — WF "Request Rejected"

**doncio.navy.mil — HTTP 200 with 253-byte "Request Rejected" body:**
- https://www.doncio.navy.mil/ContentView.aspx?ID=16442 (GenAI guardrails memo)
- https://www.doncio.navy.mil/mobile/ContentView.aspx?ID=13804&TypeID=21 (Jupiter)

**Other .mil:**
- https://www.peodigital.navy.mil/News/Article/3861151/... — curl 403; WF 403
- https://www.navy.mil/Press-Office/Press-Releases/display-pressreleases/Article/4483312/... — curl 403
- https://www.navy.mil/Press-Office/News-Stories/Article/3432370/department-of-the-navy-opens-flank-speed-azure-for-business/ — WF 403
- https://www.navsea.navy.mil/Home/Warfare-Centers/NSWC-Dahlgren/Resources/Leading-Edge/I-I-Leading-Edge/Washington02/ — WF 403
- https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500002p.PDF — curl 403; WF 403
- https://www.esd.whs.mil/portals/54/documents/dd/issuances/dodi/110022p.pdf — curl 403; WF 403
- https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500074p.pdf — curl 403; WF 403 (text obtained anyway from a search-cached copy, local 7elny6)
- https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500088p.PDF — WF 403
- https://apps.dtic.mil/sti/tr/pdf/ADA388281.pdf — curl 403
- https://www.acq.osd.mil/dpap/dars/dfars/html/previous/r20011101/appendix_g-3.htm — curl 000 (connection failed/timeout)
- https://www.acq.osd.mil/dpap/dars/dfars/html/current/appendix_g.htm — curl 000
- https://www.acq.osd.mil/asda/dpc/ce/p2p/docs/training-presentations/2024/p2p_2024-procurement_analytics_data_in_advana_part_i_508_Oct25.pdf — curl 000; WF 503
- (OK) https://ac.cto.mil/wp-content/uploads/2023/05/SEP-Outline-4.1.pdf — curl 200
- (OK) https://www.dvidshub.net/news/564931/... — curl 200

**DAU / WARU (dau.edu 301-redirects to waru.edu; waru.edu 403s everything to us):**
- https://www.waru.edu/sites/default/files/Migrated/CopDocuments/NAVAIRINST%204355.19E%20SE%20Technical%20Review%20Process%2020150206.pdf — curl 403; WF 403
- https://www.waru.edu/sites/default/files/Migrated/CopDocuments/SETR%20Process%20Handbook%20v1.0%2020150206.pdf — curl 403; WF 403
- https://www.waru.edu/navairinst-435519e-se-technical-review-process — WF 403
- https://www.waru.edu/library/defense-atl/blog/NAVAIR--Systems-Engineering-Transformation — WF 403
- https://www.waru.edu/tools/dau-systems-engineering-brainbook/technical-reviews-and-audits — WF 403
- https://www.waru.edu/sites/default/files/webform/documents/26876/What%20is%20Jupiter.pdf — curl 403
- https://aaf.waru.edu/aaf/aaf-pathways/ — WF 403
- https://aida.mitre.org/aaf/aaf-pathways/ — password-protected page

**Others:**
- https://www.incose.org/docs/default-source/orlando/nawctsd-setr-process.pdf?sfvrsn=8c58ac6_6 — curl 403; WF 403
- https://bidbanana.thebidlab.com/bid/d1YdnaOytITXOTrbGjxT — WF 403
- https://starbridge.ai/rfp/nawcad-long-range-acquisition-forecast-lraf-fy26 — reachable but attachments paywalled
- https://sam.gov/opp/f8aab2f29ba34e1a8a3298204911a4f1/view and https://sam.gov/opp/c9874ad910964d6e94a379503e415542/view — HTTP 200 but JS SPA shell only (no notice text)
- https://govtribe.com/opportunity/federal-contract-opportunity/nawcad-pax-long-range-acquisition-forecast-lraf-fy22-qtr1-nawcadpaxlraffy22 — WF 403
- https://military-history.fandom.com/wiki/Naval_Air_Systems_Command — WF 402
- https://www.acronymfinder.com/PEDDAL.html — WF 403
- https://harrykahn.com/wp-content/uploads/2018/10/2_181011_NAWCAD_Overview_Small_Business_Industry_Day_final2.pdf — WF returned empty content
- https://www.acqnotes.com/Attachments/NAVAIR%20Acquisition%20Guide%20Oct%202013.pdf — curl 000
- https://www.acquisition.gov/dfars/appendix-g-activity-address-numbers (and 5 variants) — 404
  (Appendix G is now "reserved" on acquisition.gov; DoDAAC lookup lives in DAASINQ)
- https://techcommunity.microsoft.com/blog/publicsectorblog/azure-openai-now-authorized-as-a-service-at-dod-il4-and-il5/4231171 — reachable, but only the headline rendered
- https://everyspec.com/DATA-ITEM-DESC-DIDs/DI-MISC/DI-MISC-80508B_29275/ and /DI-IPSC/DI-IPSC-81435A_3745/ — WF 404 (guessed slugs; the DIDs exist, slugs differ)
- https://www.gsa.gov/system/files/prize-challenge-toolkit-2026.pdf — downloaded (71 pp) but WF summarizer could not parse; not mined
- WebSearch budget exhausted at 200 calls; ~4 planned searches (CSS enterprise contracting,
  AIR-10.0/11.0 names, NIS details, Advana IL level) were not run.

---

## 7. Local artifacts (this directory)
- `tg_challenge.html` / `tg_challenge.txt` — official challenge page (2026-09-04 snapshot)
- `navairinst_4355_19D.doc` / `.txt` — NAVAIRINST 4355.19D full text (crude strings extract)
- `setr_handbook_v1.doc` / `.txt` — Naval SETR Handbook v1.0
- `navair_how_to_do_business.pdf` / `.txt` — NAVAIR OSBP brief (UICs, contacts, FY20 obligations)
- `navair_command_lraf_2019.pdf` / `.txt` — NAVAIR command LRAF, Feb 2019 (~1,200 rows)
- `nawcad_baa_fy25.pdf` / `.txt` — NAWCAD Office-wide BAA N00421-25-S-0001
- `sep_outline_41.pdf` / `.txt` — DoD SEP Outline v4.1
- `onr_sow_template.docx` — ONR SOW template
- `webfetch-*.txt` — text of PDFs captured by WebFetch (SETR software deck 15pgni; NAWCAD LRAF
  FY22Q4 y5q5h0; MD Commerce NAWCAD 02yqaw; NASC oxh56z; DoDI 5000.74 7elny6; Stevens/VT AIRC NLP
  report bm3p4t; MIL-HDBK-245D se36gq; OMB M-19-13 ll7sh8; GSA category PSC taxonomy x8ik4y; BIC
  list i5jce2; GSA prize toolkit 2026 9f4mv3; NPS ARS 2025 AI papers kei1pr/f3vzij; MCSC industry
  day afjc8h; others)
