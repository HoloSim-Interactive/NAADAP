# B. FAR / DFARS / NMCARS Framework Notes for a DoD Acquisition SME Agent
*Purpose: subject-matter reference for an agent that reads SOWs/PWSs/CDRLs/sources-sought notices and recommends strategic contract vehicles for requirement consolidation.*
*Compiled 2026-09-04 from primary sources (acquisition.gov FAR/DFARS/PGI/NMCARS, eCFR/LII, esd.whs.mil, OMB, GAO, CRS). Dollar thresholds are as displayed on acquisition.gov on the compile date; FAR thresholds are inflation-adjusted every five years under FAR 1.109 (last cycle effective 1 Oct 2025), so re-verify any dollar figure before relying on it in a formal determination.*

---

## 0. Quick-reference threshold table (verify before use)

| Threshold | Value (as fetched) | Cite |
|---|---|---|
| Micro-purchase threshold (MPT) | $15,000 (construction $2,000; services subject to SCA $2,500; contingency $25K/$40K) | FAR 2.101 https://www.acquisition.gov/far/2.101 |
| Simplified acquisition threshold (SAT) | $350,000 (contingency $1M/$2M; humanitarian/peacekeeping $650K) | FAR 2.101 |
| SAM.gov synopsis | ≥ $25,000; $15K–$25K public display | FAR 5.101, 5.201 https://www.acquisition.gov/far/subpart-5.2 |
| Synopsis lead / response times | 15 days before solicitation; 30-day response; 45 days R&D > SAT; 40 days WTO/FTA | FAR 5.203 |
| Consolidation written determination | > $2,000,000 (statutory, not inflation-adjusted) | FAR 7.107-2; 15 U.S.C. 657q(c)(1) |
| "Substantial" consolidation/bundling benefit | 10% of value if ≤ $94M; greater of 5% or $9.4M if > $94M | FAR 7.107-2(d), 7.107-3; 13 CFR 125.2(d)(2) |
| Substantial bundling | DoD ≥ $8M; NASA/GSA/DOE ≥ $6M; others ≥ $2.5M | FAR 7.107-4(a)(1) |
| Written acquisition plan (DoD) | ≥ $10M development; ≥ $50M all years or ≥ $25M any FY for production/services | DFARS 207.103(d)(i) https://www.acquisition.gov/dfars/part-207-acquisition-planning |
| J&A / limited-source approval | ≤ $900K CO; > $900K–$20M competition advocate; > $20M–$90M ($150M DoD/NASA/CG) HCA; above that SPE | FAR 6.304; 8.405-6; 16.505(b)(2)(ii)(C) |
| Single-award IDIQ/requirements contract | > $150M (incl. options) needs head-of-agency D&F | FAR 16.504(c)(1)(ii)(D); 16.503(b)(2) |
| Advisory & assistance IDIQ | > 3 years and > $20M → multiple awards unless exception | FAR 16.504(c)(2); 16.503(d)(1) |
| Fair-opportunity "enhanced" procedures on orders | > $7.5M (notice, response period, factors, best-value statement, debriefing) | FAR 16.505(b)(1)(iv) |
| DoD order debriefing | orders ≥ $15M (NDAA FY2018 §818) | DFARS 216.505(b)(6) |
| Order protest jurisdiction | > $10M civilian; > $25M DoD/NASA/CG (as displayed; verify current) | FAR 16.505(a)(10) |
| FSS single-award BPA | > $150M needs head-of-agency determination; 1 yr + four 1-yr options | FAR 8.405-3 |
| Subcontracting plan | ≥ $750,000 ($1.5M construction) (as displayed; verify) | FAR 19.702 |
| SAP test program for commercial | up to $9M ($15M contingency/cyber/disaster) | FAR 13.500 |
| CPARS | > SAT; construction ≥ $900K; A-E ≥ $45K | FAR 42.1502 |
| DoDI 5000.74 S-CAT bands | see §2.5 | DoDI 5000.74 Table 1 |
| SRRB required | services ≥ $10M (incl. IDIQ base and task orders ≥ $10M) | DoDI 5000.74 §4.3.c |
| Non-performance-based services approval (DoD) | ≤ $100M designated official; > $100M SPE | DFARS 237.170-2 |
| Category-management AoA | > $50M planned Tier 0; > $100M planned Tier 1 | OMB M-19-13 §c |

---

## 1. FAR structure: parts an SME must know cold

Source index: https://www.acquisition.gov/browse/index/far

### FAR Part 1 — Federal Acquisition Regulations System
- 1.102 guiding principles; 1.602-1 CO authority; 1.602-2(d) COR: must be a Government employee, certified (FAC-COR / DoD policy), designated in writing with authority limits, "has no authority to make any commitments or changes that affect price, quality, quantity, delivery," designation not redelegable, COR "may be personally liable for unauthorized acts." https://www.acquisition.gov/far/1.602-2
- 1.109 statutory acquisition-related dollar thresholds adjusted for inflation every 5 years.
- **Consolidation-analysis meaning:** the agent should never attribute authority to a COR/PM; only the CO signs determinations. Any recommended vehicle must trace to a CO with authority for that vehicle (e.g., DON HCA vs. DASN(P)).

### FAR Part 2 — Definitions (2.101) https://www.acquisition.gov/far/2.101
Key verbatim-ish definitions:
- **Bundling**: "a subset of consolidation that combines two or more requirements for supplies or services, previously provided or performed under separate smaller contracts (see paragraph (2) of this definition), into a solicitation for a single contract, a multiple-award contract, or a task or delivery order that is likely to be unsuitable for award to a small business concern" (because of diversity/size/specialized nature, aggregate value, geographic dispersion, or combination).
- **Consolidation or consolidated requirement**: "a solicitation for a single contract, a multiple-award contract, a task order, or a delivery order to satisfy two or more requirements of the Federal agency for supplies or services that have been provided to or performed for the Federal agency under two or more separate contracts, each of which was lower in cost than the total cost of the contract for which offers are solicited" (and construction at multiple sites).
- **Multiple-award contract**: a GSA MAS contract, a multiple-award task/delivery-order contract under 16.5, or any other IDIQ contract with two or more sources.
- **Performance-based acquisition**: "an acquisition structured around the results to be achieved as opposed to the manner by which the work is to be performed."
- **Performance work statement**: "a statement of work for performance-based acquisitions that describes the required results in clear, specific and objective terms with measurable outcomes."
- **Statement of objectives**: (defined in 37.601/37.602; see §3) Government-provided objectives from which offerors write the PWS.
- **GWAC**: "a task-order or delivery-order contract for information technology established by one agency for Governmentwide use" under Clinger-Cohen (40 U.S.C. 11302(e)) executive-agent designation.
- **Commercial product / commercial service / COTS**: FAR 2.101 (long definitions; services "of a type offered and sold competitively in substantial quantities in the commercial marketplace based on established catalog or market prices").
- **Consolidation meaning:** The distinction *bundling ⊂ consolidation* drives which determination is required. Consolidation triggers on value (> $2M) and prior performance under separate contracts regardless of business size; bundling adds "previously performed by/suitable for small business" and "likely unsuitable for small business." An NLP pipeline should flag both the incumbent contract numbers and incumbent business size.

### FAR Part 5 — Publicizing Contract Actions https://www.acquisition.gov/far/subpart-5.2
- 5.101 $25K GPE (SAM.gov) synopsis; 5.201 synopsis of contract actions; 5.202 exceptions (incl. orders under 16.5 contracts, national security, urgency, ≤ SAT with electronic access); 5.203 15-day/30-day/45-day timing; 5.204 presolicitation notices; 5.205 special situations (R&D advance notices, A-E, FFRDC 90-day).
- Sources-sought notices are posted as SAM.gov notice type "Sources Sought" as a Part 10 market-research technique (10.002(b)(2)); RFIs under 15.201(e).
- **Consolidation meaning:** orders under existing MACs/GWACs/FSS need no SAM synopsis (5.202(a)(6)/8.404), which is a major schedule advantage of recommending an existing vehicle over a new full-and-open contract; however 7.107-5 requires a *separate* GPE notice of a consolidation/bundling determination at least 7 days before the solicitation.

### FAR Part 6 — Competition Requirements https://www.acquisition.gov/far/subpart-6.3
- 6.101 full and open competition; 6.102(d)(3) FSS orders and 6.102(d)(2) BAA count as competitive procedures.
- 6.302 seven exceptions: -1 only one responsible source; -2 unusual and compelling urgency; -3 industrial mobilization / engineering, developmental, research capability / expert services; -4 international agreement; -5 authorized or required by statute (includes 8(a), HUBZone, SDVOSB sole source); -6 national security; -7 public interest (10 U.S.C. 3204(a)(1)-(7) / 41 U.S.C. 3304(a)(1)-(7)).
- 6.303-1 J&A required before negotiating sole source; 6.303-2 J&A content (12 elements: agency/activity, nature of action, description and estimated value, authority cited, demonstration of unique qualifications, efforts to solicit others/notice, fair-and-reasonable determination, market research, other facts, sources expressing interest, actions to remove barriers to future competition, CO certification).
- 6.304 approvals: ≤ $900K CO; > $900K–$20M competition advocate; > $20M–$90M (DoD/NASA/CG $150M) HCA; above → SPE.
- **Consolidation meaning:** a consolidated requirement that pulls in a sole-source component (e.g., OEM-proprietary sustainment) forces a J&A for the whole or a carve-out; conversely, a logical follow-on order under a MAC uses 16.505(b)(2)(i)(C), not Part 6. Check each incumbent contract's competition code.

### FAR Part 7 — Acquisition Planning https://www.acquisition.gov/far/subpart-7.1
- 7.102 policy: acquisition planning and market research for all acquisitions to promote commercial items and full and open competition.
- 7.103 agency-head responsibilities: structure requirements "to facilitate competition by and among small business concerns" and avoid unnecessary bundling (15 U.S.C. 631(j)); performance-based methods for services; no purchase request that results in contractor performance of inherently governmental functions; contract-type documentation; coordination with competition advocate when other than full and open.
- 7.104 planner forms an integrated team; plan reviewed no less than annually.
- **7.105 acquisition plan contents** (full list in §3.7 below).
- **7.107 Consolidation, bundling, substantial bundling** — the central section:
  - 7.107-1 General: if a requirement is both consolidated and bundled, follow bundling guidance (7.107-3 to -5). Not applicable to: A-76 cost comparisons (except 7.107-4), orders under single-agency task/delivery-order contracts where the base contract's consolidation/bundling was already justified, and mandatory sources (8.002/8.003). https://www.acquisition.gov/far/7.107-1
  - 7.107-2 Consolidation (> $2M): SPE or CAO written determination that consolidation is "necessary and justified" after (1) market research, (2) identification of "alternative contracting approaches that would involve a lesser degree of consolidation," (3) coordination with the agency small-business office (OSDBU/OSBP), (4) identification of negative impacts on small business, (5) steps to include small business. Justified when benefits "substantially exceed" alternatives; benefit categories: cost savings/price reduction, quality improvements that save time or enhance performance, reduced acquisition cycle time, better terms and conditions, other. "Substantial" = 10% of value ≤ $94M; greater of 5% or $9.4M above $94M. (e) mission-critical exception if strategy provides maximum practicable small-business participation; (f) determination goes in acquisition strategy documentation and to SBA on request. https://www.acquisition.gov/far/7.107-2
  - 7.107-3 Bundling: written determination "necessary and justified" (15 U.S.C. 644(e)); "measurably substantial benefits" at the same 10% / 5%-or-$9.4M levels; "Reduction of administrative or personnel costs alone is not sufficient justification for bundling unless the cost savings are expected to be at least ten percent" of the bundled value. https://www.acquisition.gov/far/7.107-3
  - 7.107-4 Substantial bundling (DoD $8M; NASA/GSA/DOE $6M; others $2.5M, cumulative incl. options for MACs/orders): acquisition strategy must add specific benefits, impediments to small-business prime participation, actions to maximize small-business primes (incl. teaming), actions to maximize small-business subcontractors at any tier, justification, and alternative strategies with rationale for rejection. https://www.acquisition.gov/far/7.107-4
  - 7.107-5 Notifications: notify each incumbent small business ≥ 30 days before solicitation with SBA PCR contact; publish GPE notice of the consolidation/substantial-bundling determination and do not publicize the solicitation until 7 days after; notify SBA PCR ≥ 30 days before follow-on bundled solicitation with achieved savings/cost-benefit analysis; annual public list of bundled requirements. https://www.acquisition.gov/far/7.107-5
  - 7.107-6: insert provision 52.207-6 (solicit small business teaming arrangements/JVs) in MAC solicitations above the substantial-bundling threshold. https://www.acquisition.gov/far/7.107-6
- **Consolidation meaning:** this is the compliance spine of any consolidation recommendation. The agent's output must compute (a) total estimated value incl. options; (b) whether > $2M; (c) whether any incumbent contract is small; (d) whether > agency substantial-bundling threshold; (e) quantified benefits vs. the 10%/5%/$9.4M test; (f) alternatives with lesser consolidation; and (g) the signatory (SPE/CAO; DON: DASN(P) or HCA per NMCARS 5207.107-2).

### FAR Part 8 — Required Sources https://www.acquisition.gov/far/part-8 ; https://www.acquisition.gov/far/subpart-8.4
- 8.002 mandatory priority for supplies: agency inventories → excess from other agencies → FPI → AbilityOne Procurement List → wholesale supply sources (GSA/DLA/VA/military ICPs); services: AbilityOne Procurement List.
- 8.003 other mandatory sources (utilities Part 41, printing 8.8, leased vehicles 8.11, stockpile materials). 8.004 non-mandatory, no priority order: FSS, GWACs, MACs, BPAs under FSS, then commercial sources.
- 8.402 FSS program managed by GSA; prices already found fair and reasonable. 8.404(a): FSS BPAs and orders "are considered to be issued using full and open competition"; Parts 13, 14, 15, and 19 do not apply (but 8.405-5 allows set-asides at CO discretion).
- 8.405-1 (no SOW) / 8.405-2 (with SOW): ≤ MPT any schedule contractor; > MPT ≤ SAT RFQ to ≥ 3; > SAT post on e-Buy or send to enough contractors to obtain ≥ 3 quotes; best value; document. 8.405-2 requires an SOW/PWS-type description, evaluation criteria, and consideration of the "level of effort and mix of labor."
- 8.405-3 BPAs: single-award BPA ≤ 1 year + four 1-year options and head-of-agency determination if > $150M; multiple-award BPAs normally ≤ 5 years; annual review.
- 8.405-6 limited sources justification and posting; approvals ≤ $900K CO; > $900K–$20M advocate; > $20M–$90M HCA; > $90M SPE.
- **Consolidation meaning:** GSA MAS is the default "quick" consolidation vehicle for commercial services (PSC D/R/J etc.) but carries per-order competition (3-quote/e-Buy) rather than a single competed award; multi-award BPAs under MAS are a common way to consolidate recurring like requirements across an enclave without a new IDIQ. DoD ordering from MAS/GWACs must also pass DFARS 217.770 (non-DoD contract review).

### FAR Part 10 — Market Research https://www.acquisition.gov/far/10.001 ; https://www.acquisition.gov/far/10.002
- 10.001(a)(2) required: before developing new requirements documents; before soliciting > SAT; below SAT when information is inadequate; **"before soliciting offers for acquisitions that could lead to consolidation or bundling"**; before awarding a task/delivery order under an IDIQ > SAT for other-than-commercial; ongoing for contingency/disaster small-business capability.
- 10.001(c): when bundling is contemplated, consult the agency small-business specialist and SBA PCR during market research; notify incumbent small businesses.
- 10.002(b)(2) techniques: contact knowledgeable Government/industry individuals; review prior market research; publish RFIs in journals/business publications (sources-sought); query Government/commercial databases (contractdirectory.gov, SAM, FPDS); online interchanges; source lists from other activities/trade associations; catalogs/literature; interchange meetings/presolicitation conferences. Research ≤ 18 months old may be reused if still current (10.002(b)(1)).
- 10.002(e): document results appropriate to size/complexity. DoD: PGI 210.070 Market Research Report Guide (referenced by DFARS 237.102-78).
- **Consolidation meaning:** the consolidation determination is legally dependent on market research; the agent should treat a sources-sought notice as evidence of Step 3 of the DoD seven-step process and extract from it the Government's stated scope, NAICS/PSC, set-aside intent and requested capability data.

### FAR Part 11 — Describing Agency Needs https://www.acquisition.gov/far/11.002 ; https://www.acquisition.gov/far/subpart-11.1
- 11.002(a): specify needs using market research to promote full and open competition; state requirements "in terms of (A) functions to be performed, (B) performance required, or (C) essential physical characteristics"; give commercial products/services the opportunity to compete. Also metric, sustainable products, Section 508, IPv6, no telecommuting prohibition without justification.
- 11.101 order of precedence: (1) documents mandated by law; (2) performance-oriented documents (PWS or SOO); (3) detailed design-oriented documents; (4) standards/specs/data-item descriptions for nonrepetitive acquisitions. Use voluntary consensus standards (OMB A-119).
- 11.104 brand name or equal requires salient characteristics. 11.106 service purchase descriptions: prohibit inherently governmental performance, contractor personnel identification, marking of contractor documents.
- 11.6 DPAS: DO/DX rated orders; 15 CFR 700; provision 52.211-14, clause 52.211-15. https://www.acquisition.gov/far/subpart-11.6
- **Consolidation meaning:** if incumbent requirements are written as SOWs (design/how) and others as PWSs (results), consolidation into one PWS requires harmonizing performance standards; the agent should note the document type of each source requirement and whether "shall"-statements are results-oriented (PWS-compatible) or method-prescriptive.

### FAR Part 12 — Commercial Products/Services https://www.acquisition.gov/far/subpart-12.1 ; https://www.acquisition.gov/far/subpart-12.2
- 12.101 conduct market research; acquire commercial when available; flow-down to primes. 12.102(c) Part 12 takes precedence over conflicting FAR parts. 12.102(f) certain defense/recovery items may be treated as commercial.
- 12.202 market research is "an essential element" of the commercial description of need. 12.203 combine Part 12 with Part 13, 14 or 15 procedures.
- 12.207: FFP or FP-EPA required; T&M/LH only if competitive procedures, D&F, ceiling price, and plan to maximize FFP later; cost-type prohibited (12.207(e)).
- **Consolidation meaning:** if all sub-requirements are commercial services (most PSC D3xx IT services, R4xx support), the consolidated vehicle must be FFP/FP-EPA (or T&M with D&F); this can be a reason to keep non-commercial developmental work (cost-type) on a separate vehicle rather than forcing it into a commercial IDIQ. NMCARS 5237.102 exempts Part 12 actions from mandatory SeaPort consideration.

### FAR Part 13 — Simplified Acquisition https://www.acquisition.gov/far/part-13
- 13.003 use SAP to maximum extent ≤ SAT; acquisitions > MPT and ≤ SAT reserved for small business (19.502-2(a)); 13.104 promote competition, ordinarily ≥ 3 sources; 13.106-1 single-source justification documented; 13.303 BPAs ("simplified method of filling anticipated repetitive needs" via charge accounts) with individual purchase limit ≤ SAT except FSS BPAs; 13.5 commercial SAP test up to $9M ($15M contingency/cyber/disaster).
- **Consolidation meaning:** a cluster of many sub-SAT buys is the classic Tier 0 consolidation target; consolidating them above the SAT strips the automatic small-business reservation and can trigger 7.107. A Part 13 BPA (or FSS BPA) is a low-friction alternative to a new IDIQ.

### FAR Part 15 — Contracting by Negotiation https://www.acquisition.gov/far/subpart-15.2 ; https://www.acquisition.gov/far/15.204-5 ; https://www.acquisition.gov/far/subpart-15.3
- 15.201 exchanges with industry: industry days, one-on-ones, presolicitation notices, draft RFPs, site visits; **15.201(e) RFI** "may be used when the Government does not presently intend to award a contract, but wants to obtain price, delivery, other market information, or capabilities for planning purposes"; responses are not offers. Provision 52.215-3 Request for Information or Solicitation for Planning Purposes.
- 15.203 RFP contents: requirement, anticipated T&Cs, information required, evaluation factors and relative importance.
- 15.204-1 Uniform Contract Format (Table 15-1): Part I Schedule — A Solicitation/contract form; B Supplies or services and prices/costs; C Description/specifications/statement of work; D Packaging and marking; E Inspection and acceptance; F Deliveries or performance; G Contract administration data; H Special contract requirements. Part II — I Contract clauses. Part III — J List of attachments. Part IV — K Representations/certifications; L Instructions, conditions, notices to offerors; M Evaluation factors for award.
- 15.304(c): price/cost always evaluated; quality via non-cost factors (past performance, technical excellence, management capability, personnel qualifications, prior experience); past performance evaluated > SAT unless documented; **(c)(4) for unrestricted acquisitions involving consolidation or bundling with significant subcontracting opportunities, proposed small-business subcontracting participation is an evaluation factor**; 15.304(e) relative-importance statement. 15.101-1 tradeoff; 15.101-2 LPTA (DFARS 215.101-2-70 limits LPTA).
- **Consolidation meaning:** a consolidated competitive award must add small-business participation as a Section M factor; Section L/M content of an existing MAC (e.g., SeaPort-NxG functional areas) tells the agent whether the consolidated scope is "in scope" of the base contract.

### FAR Part 16 — Types of Contracts https://www.acquisition.gov/far/part-16 ; https://www.acquisition.gov/far/16.504 ; https://www.acquisition.gov/far/16.505 ; https://www.acquisition.gov/far/subpart-16.6
- 16.104 factors for selecting type: price competition, price/cost analysis, complexity, urgency, period of performance, contractor capability/accounting system, concurrent contracts, subcontracting, acquisition history.
- 16.301-3 cost-reimbursement limitations: written acquisition plan approved one level above the CO; adequate accounting system; Government resources for surveillance; prohibited for commercial. 16.401 incentive contracts need HCA-signed D&F; award-fee: no rollover, no fee for less than satisfactory.
- 16.5 Indefinite-delivery: 16.501-2 three types (definite-quantity, requirements, indefinite-quantity). 16.503 requirements contracts (single-source > $150M needs D&F; A&AS > 3 yr/$20M multiple awards). 16.504 IDIQ: Government must order at least the stated minimum (more than nominal), contractor must furnish up to the maximum; contract must state period incl. options, min/max, an SOW "reasonably describing the general scope, nature, complexity, and purpose," ordering procedures, ordering activities. Multiple-award preference "to the maximum extent practicable"; single-award D&F exceptions (only one capable, better terms with single, administration cost outweighs, integrally related tasks, ≤ SAT, not in Government's interest); > $150M single award needs head-of-agency D&F (DoD: SPE, "integrally related...only a single source can efficiently perform," DFARS 216.504(c)(1)(ii)(D)).
- 16.505 ordering: (a)(2) orders must be within scope, period, and maximum; (a)(3)-(4) no orders for other agencies' requirements except under GWACs/MACs authorized by 17.5; (a)(7) LPTA limits; (a)(10) order protests only for scope/period/value increase or > $10M (> $25M DoD/NASA/CG as displayed). **(b)(1) fair opportunity** to each awardee for orders > MPT; > SAT must be placed on a competitive basis with notice to all awardees; > $7.5M requires notice of the requirement, reasonable response period, disclosure of significant evaluation factors and relative importance, written best-value statement, and postaward debriefing opportunity. (b)(2)(i) exceptions: (A) urgency, (B) unique/highly specialized—only one awardee capable, (C) logical follow-on to an order already competed, (D) minimum guarantee, (E) statute, (F) set-aside under 19.504(c)(1)(ii), (G) DoD/NASA/CG 6.302 exceptions. (b)(2)(ii) justification with approval tiers matching 6.304. (b)(3) pricing per 15.4 if not established; (b)(8) ombudsman.
- 16.6: T&M/LH need D&F that no other type is suitable, ceiling price, HCA approval if base + options > 3 years; hourly rates include wages, overhead, G&A, profit. 16.603 letter contract: definitize within 180 days or 40% of work; ≤ 50% funding. 16.7 BOAs/basic agreements (BPAs are in 13.303).
- 17.5 interagency acquisition (FSS, GWACs, MACs): assisted vs. direct; interagency agreement required for assisted; 17.502-1 best-procurement-approach determination; Economy Act D&F (17.502-2). https://www.acquisition.gov/far/subpart-17.5
- **Consolidation meaning:** the agent's vehicle taxonomy is: new single-award contract; new agency IDIQ (single/multiple); order under existing agency MAC (fair opportunity — scope check against base SOW and ceiling/ordering period); order under GWAC/GSA MAS/BIC (Part 17.5 + DFARS 217.770); FSS BPA; Part 13 BPA/BOA. Each carries different consolidation-determination applicability (7.107-1(b)(2) exempts orders under a single-agency IDIQ whose base contract was already justified).

### FAR Part 19 — Small Business Programs https://www.acquisition.gov/far/part-19 ; https://www.acquisition.gov/far/19.102 ; https://www.acquisition.gov/far/subpart-19.2 ; https://www.acquisition.gov/far/subpart-19.5
- 19.102 NAICS: CO assigns one NAICS code and size standard that "best describes the principal purpose" of the acquisition (greatest percentage of value); for MACs, from 1 Oct 2028 the CO may assign multiple NAICS by distinct portion/category and orders use the NAICS of that portion; NAICS appeal to SBA OHA.
- 19.201 maximum practicable opportunity; 19.202-1 divide into reasonably small lots, realistic schedules; **19.202-1(e)** ≥ 30-day notice to SBA PCR when work currently performed by small business is proposed in quantities/consolidations unlikely for small-business award, with a statement why it cannot be divided, scheduled, structured, or acquired as discrete construction projects, and that consolidation/bundling is "necessary and justified."
- 19.203 relationship: above SAT no order of precedence among 8(a)/HUBZone/SDVOSB/WOSB; below SAT socioeconomic programs may be used instead of the automatic reservation.
- 19.502-2 automatic reservation > MPT ≤ SAT; rule of two above SAT. 19.502-3 partial set-asides; 19.502-4 MAC set-asides/partial set-asides/reserves; 19.503 class set-asides; 19.504 orders under MACs set-aside (19.504(c)); 19.505 limitations on subcontracting (services 50%, supplies 50%, general construction 85%, special trade 75%). 19.702 subcontracting plan thresholds. 19.8 8(a); 19.13 HUBZone; 19.14 SDVOSB; 19.15 WOSB.
- 13 CFR 125.2(e) (SBA): CO "must set-aside a Multiple Award Contract if the requirements for a set-aside are met," may partially set aside or reserve, must document why not; may set aside orders on unrestricted MACs (aim ≥ 50% of dollars available to all holders is encouraged). https://www.law.cornell.edu/cfr/text/13/125.2
- **Consolidation meaning:** the killer question for any consolidation is whether it destroys a set-aside-eligible lot. The agent should run rule-of-two logic per sub-requirement (incumbent size, NAICS size standard, sources-sought responses) and prefer structures preserving set-asides: partial set-aside, reserved awards, order-level set-asides on the MAC, or small-business-only pools.

### FAR Part 37 — Service Contracting https://www.acquisition.gov/far/subpart-37.1 ; https://www.acquisition.gov/far/subpart-37.6 ; https://www.acquisition.gov/far/subpart-37.5
- 37.101 definitions: service contract; nonpersonal vs. personal services; A&AS (37.2: management/professional support, studies/analyses/evaluations, engineering & technical services). 37.104 personal-services indicators (on-site, GFE, integral mission support, comparable civil-service work, > 1 year, Government direction/supervision). 37.102(a): PBA "to the maximum extent practicable" with order of precedence (1) FFP PBA, (2) other PBA, (3) non-PBA; exclusions A-E, construction, utilities, services incidental to supplies. 37.114 contractor identification. 37.115 uncompensated overtime.
- 37.5 management oversight: clear requirements, performance standards, best practices; contracts ≤ SAT excluded.
- **37.6 Performance-based acquisition**: 37.601 solicitation may use a PWS or a SOO; PBA contracts must include a PWS, measurable performance standards (quality, timeliness, quantity) and method of assessing performance, and incentives where appropriate. 37.602(b): describe work "in terms of the required results rather than either 'how' the work is to be accomplished or the number of hours"; enable assessment against measurable standards. 37.602(c) SOO minimum content: purpose; scope or mission; period and place of performance; background; performance objectives (required results); any operating constraints. 37.603 standards; 37.604 QASP per 46.4 (Government-prepared or offeror-proposed).
- 46.401(a): "Quality assurance surveillance plans should be prepared in conjunction with the preparation of the statement of work. The plans should specify—(1) All work requiring surveillance; and (2) The method of surveillance." https://www.acquisition.gov/far/subpart-46.4
- **Consolidation meaning:** consolidated services must be PBA-first and FFP-first; a consolidated PWS needs one integrated QASP/PRS. Non-PBA needs DFARS 237.170-2 approval. Personal-services red flags in incumbent SOWs (e.g., "contractor shall report to the Government supervisor") must be scrubbed.

### FAR Part 42 — Contract Administration https://www.acquisition.gov/far/subpart-42.3 ; https://www.acquisition.gov/far/subpart-42.15
- 42.202 assignment to CAO (DCMA); 42.302(a) delegated functions (forward pricing rates, final indirect rates, accounting-system adequacy, payments, overrun notification); 42.302(b) functions only with CO authorization (modifications).
- 42.15 CPARS: evaluations for contracts/orders > SAT (construction ≥ $900K, A-E ≥ $45K), at least annually and at completion; factors technical, cost control, schedule, management, small-business subcontracting, regulatory compliance; ratings Exceptional–Unsatisfactory; 14-day contractor comment.
- **Consolidation meaning:** consolidation concentrates administration into fewer CORs/COs and one CPARS record; the agent should identify the incumbent ACO/CAO, PCO, and COR structure and whether the consolidated vehicle changes DCMA delegation.

---

## 2. DFARS / PGI / NMCARS / DoD services-acquisition policy

### 2.1 Consolidation (DFARS 207.170 history)
- DFARS 207.170 ("Consolidation of contract requirements," implementing former 10 U.S.C. 2382, $6M/$5M DoD threshold) was **deleted** by DFARS Case 2017-D004 final rule, 83 FR 15776, effective 13 Apr 2018, because 10 U.S.C. 2382 was repealed by NDAA FY2013 §1671 and consolidation is now governed government-wide by 15 U.S.C. 657q and FAR 7.107; DFARS 219.201(c)(11)(A) now points to FAR 7.107. https://www.federalregister.gov/documents/2018/04/13/2018-07732/defense-federal-acquisition-regulation-supplement-consolidation-of-contract-requirements-dfars-case ; acquisition.gov DFARS Part 207 shows 207.170 "Reserved." https://www.acquisition.gov/dfars/part-207-acquisition-planning
- GAO-14-36 (Nov 2013) had found DoD regulations still reflected the old $6M threshold after the 2010 statute lowered it to $2M; recommendations closed by 2018. https://www.gao.gov/products/gao-14-36
- DFARS 207.103(d)(i): written acquisition plans required ≥ $10M development, ≥ $50M all years or ≥ $25M any FY production/services; not required for final buy-out/one-time buy. DFARS PGI 207.105 adds DoD contents (budget line items/program elements, market research for commercial alternatives, technical data rights, industrial base). https://www.acquisition.gov/dfarspgi/pgi-207.1-acquisition-plans

### 2.2 Indefinite-delivery / MAC ordering (DFARS 216.5) https://www.acquisition.gov/dfars/216.504-indefinite-quantity-contracts. ; https://www.acquisition.gov/dfars/216.505-ordering.
- 216.504(c)(1)(ii)(D)(1): SPE holds the FAR 16.504(c)(1)(ii)(D)(1) single-award authority; must find orders "so integrally related that only a single source can efficiently perform the work" (10 U.S.C. 3403(d)(3)); congressional notification does not apply to DoD; determination not required if a Part 6.3/206.3 justification exists.
- 216.505(a)(S-70): orders > SAT against non-DoD contracts must follow subpart 217.7 review/approval/reporting. (a)(S-71) SPRS price/supplier/item risk considered. (b)(1)(A) LPTA limits per 215.101-2-70; (b)(1)(B) reverse auctions prohibited for PPE/aviation CSIs (217.7801). (b)(2) follow-on exceptions require 216.505(b)(2) procedures. **(b)(6) debriefings required for orders ≥ $15M** (NDAA FY2018 §818; 215.506-70). 216.505-70: only one offer on a competitive order > SAT → follow 215.371 (30-day resolicitation or cost/price analysis). https://www.acquisition.gov/dfars/216.505-70-orders-under-multiple-award-contracts. ; https://www.acquisition.gov/dfars/215.371-only-one-offer.
- 216.500: A-E under 16.5 follows FAR 36.6 (10 U.S.C. 3406(h)(1)).

### 2.3 Use of non-DoD contracts (DFARS 217.7 / 217.770) https://www.acquisition.gov/dfars/217.770-procedures.
- Departments must have procedures to review orders > SAT placed on non-DoD contracts (GWACs, GSA MAS, other agencies' MACs): evaluate whether use is in DoD's best interest considering "satisfying customer requirements," schedule, "cost effectiveness (taking into account discounts and fees)," and contract administration/oversight; confirm tasks are within scope of the selected contract; confirm funding complies with appropriation limits and DoD-unique statutes/regulations; collect assisted-acquisition data (subpart 204.6); PGI 217.770(a)(3) fee awareness. (Note: acquisition.gov currently labels subpart 217.78 "Reverse Auctions"; the non-DoD-contract policy lives in 217.7.)
- **Meaning:** recommending a GSA/NIH/NASA BIC vehicle for a DoD requirement is legitimate but requires a documented best-interest determination and fee comparison versus a DoD vehicle (e.g., SeaPort-NxG, which has no fee to Navy users).

### 2.4 Services acquisition (DFARS 237) https://www.acquisition.gov/dfars/part-237-service-contracting ; https://www.acquisition.gov/dfarspgi/pgi-237.1-service-contracts-general
- 237.102-70 firefighting/security-guard limits; 237.102-72 management services contracts must bar inherently governmental functions; 237.102-73 no senior mentors; **237.102-74 taxonomy** → PGI 237.102-74 (OUSD(A&S)/DPAP memo "Taxonomy for the Acquisition of Services and Supplies & Equipment," 27 Aug 2012; Excel at acq.osd.mil/dpap/dars/pgi/docs/Acquisition_services_taxonomy.xlsx) https://www.acquisition.gov/dfarspgi/pgi-237.102-74-taxonomy-acquisition-services-and-supplies-equipment. ; 237.102-75 DAG Ch. 10; 237.102-76 software in services contracts (227.7202/7203); 237.102-77 (PGI) ARRT tool "should be used to prepare [PWS, QASP, PRS] for all performance-based acquisitions for services"; 237.102-78 market research report guide (PGI 210.070); 237.102-79 in-sourcing notification (20 business days).
- 237.170-2 non-performance-based services approval: ≤ $100M official designated by department/agency; > $100M SPE.
- 237.172 surveillance: "ensure that quality assurance surveillance plans are prepared in conjunction with the preparation of the statement of work"; 237.171 training; 237.503 personal-services safeguards.
- DFARS 215.470 estimated data prices: "When data are required to be delivered under a contract, include DD Form 1423, Contract Data Requirements List, in the solicitation"; check for duplication. https://www.acquisition.gov/dfars/215.470-estimated-data-prices.

### 2.5 DoDI 5000.74 Defense Acquisition of Services (10 Jan 2020; reissues 5 Jan 2016) https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500074p.pdf (403 on fetch; text taken from AcqNotes mirror https://acqnotes.com/wp-content/uploads/2021/03/DoD-Instruction-5000.74-Defense-Acquisition-of-Services-10-Jan-20.pdf )
- Applies to services acquisitions ≥ SAT and all A&AS supporting R&D/construction in the knowledge-based portfolio group.
- **Table 1 S-CAT decision authorities (threshold on IGCE, current-year dollars):**

| S-CAT | Threshold | Decision authority |
|---|---|---|
| Special Interest | as designated by USD(A&S)/ASD(A) | USD(A&S) or ASD(A) |
| I | ≥ $1B total, or > $300M in any one year | SAE/CAE or designee |
| II | ≥ $250M and < $1B | SAE/CAE or designee |
| III | ≥ $100M and < $250M | Component Senior Services Manager (SSM) or designee |
| IV | ≥ $10M and < $100M | Component SSM or designee |
| V | > SAT and < $10M | Component SSM or designee |

- §1.2.e "Seven Steps to the Services Acquisition Process" (Figure 1) shall be used; §1.2.k "Existing government-wide contracts should be used to the maximum extent practicable" for the Federal Category Structure; §1.2.l strategy must manage intellectual property for competitive follow-on transitions; §3.3.c Federal taxonomy = 19 categories (10 common + 9 DoD-centric), of which the DoD *services* structure is 14 categories; §3.3.b requirements addressed "from an appropriate enterprise-level (e.g., DoD Component-wide, DoD-wide, or best-in-class solution)."
- §4.3 SRRB: required for services ≥ $10M (10 U.S.C. 2330), including IDIQ base and each task order ≥ $10M; validates requirements before strategy execution/option exercise, prioritizes for funding, identifies savings via reduced service levels, in-sourcing (10 U.S.C. 2463) or elimination.
- §4.4 services acquisition strategy (Acquisition Plan at DFARS 207.103(d)(i)(B) thresholds; streamlined documentation between SAT and that threshold) must cover: source of requirement, outcomes/metrics, how previously satisfied, market research summary, **"a summary that addresses consolidated or bundled requirements, if it applies,"** AoA summary; approach/milestones, cost estimate, funding, PBSA or rationale, small-business opportunities, evaluation criteria, competition rationale, multi-year, waivers; business arrangement type (single contract, MATOC, task order under existing MAC), duration (base + options), pricing arrangement (FP, CR, T&M, LH); risk plan (incl. external assisted acquisitions under the Economy Act); performance-management approach.
- The DAU seven steps (Service Acquisition Mall / AAF): 1 Form the team; 2 Review current strategy; 3 Market research; 4 Requirements definition; 5 Acquisition strategy; 6 Execute strategy; 7 Performance management. (DAU AAF services pathway: https://aaf.waru.edu/aaf/services/ — waru.edu is the current redirect target of dau.edu.)

### 2.6 DoD services taxonomy / PSC portfolio groups
- PSC structure (GSA PSC Manual, latest edition April 2025 https://www.acquisition.gov/psc-manual ): four-character codes; services begin with a letter, products with a digit. Service leading letters: A R&D; B special studies/analyses; C architect/engineering; D IT & telecom (D3xx); E purchase of structures; F natural resources; G social services; H quality control/testing/inspection; J maintenance/repair/rebuild of equipment; K modification of equipment; L technical representative; M operation of Government-owned facilities; N installation of equipment; P salvage; Q medical; R professional/administrative/management support (R4xx); S utilities/housekeeping; T photographic/mapping/printing/publications; U education/training; V transportation/travel/relocation; W lease/rental of equipment; X lease/rental of facilities; Y construction; Z maintenance/repair/alteration of real property.
- DoD taxonomy (DPAP memo 27 Aug 2012, PGI 237.102-74): 16 portfolio groups (9 services, 7 S&E), 70 portfolios (40 services, 30 S&E). **Services portfolio groups:** Knowledge Based Services; Research & Development; Facility Related Services; Logistics Management Services; Equipment Related Services; Electronic & Communication Services; Medical Services; Transportation Services; Construction Services. (Group list per DAU taxonomy artifact https://www.waru.edu/artifact/taxonomy-acquisition-supplies-and-equipment-and-services and DoDI 5000.74 references; the memo PDF itself returned 503.)
- Government-wide Category Management taxonomy (GSA GWCM "User Guide: Category PSC Taxonomy," 5 Mar 2018, https://ag-dashboard.acquisitiongateway.gov/system/files/category-management/2023-08/User%20Guide_%20GWCM%20PSC%20Taxonomy-1522170042-1526566790-1642789961.pdf ): rules map each FPDS PSC (plus NAICS/keyword refinements) to Level 1/2/3 categories; "10 'Common Spend' categories central to the focus of Government Wide Category Management, as well as the 9 'Defense-Centric' spend categories." Level-1 names present in the guide's examples: Facilities & Construction; Professional Services; IT; Human Capital; Security and Protection; Industrial Products & Services; Transportation and Logistics Services; Equipment Related Services; Research and Development; Weapons & Ammunition; Miscellaneous S&E. (Remaining common categories per GSA: Medical, Office Management, Travel & Lodging; remaining defense-centric: Aircraft/Ships-Submarines/Land Vehicles, Electronic & Communication Equipment, Sustainment S&E, Clothing/Textiles/Subsistence S&E, Electronic & Communication Services, Facility Related Services — treat these as secondary until confirmed against the GWCM mapping spreadsheet.)
- Example mappings from the guide: Y122 → Facilities & Construction / Construction Related Services; H941, H134, L038 → Equipment Related Services; AN81, AV41 → Research and Development / Technology Base; AV96 → Professional Services / Research & Development; Z1NE, M1HZ → Facilities & Construction / Facility Related Services; R431 + NAICS 541611/541612/561311 → Human Capital sub-categories.
- **Meaning for the agent:** PSC (first letter and 4-char code) is the primary key for portfolio assignment, spend-under-management tiering and BIC eligibility; NAICS is the key for size standards/set-asides. Extract both from every document.

### 2.7 NMCARS (Navy/Marine Corps) https://www.acquisition.gov/nmcars/part-5207-acquisition-planning ; https://www.acquisition.gov/nmcars/part-5237-service-contracting ; https://www.acquisition.gov/nmcars/part-5216-types-contracts ; PDF (FY2019 ed.) https://www.acquisition.gov/sites/default/files/current/nmcars/pdf/NMCARS.pdf
- 5207.103: STRAPs (streamlined acquisition plans) required at DFARS 207.103(d)(i) thresholds and for task/delivery orders whose value requires an AP; DASN(P) approves APs with any individual contract action ≥ $250M, otherwise HCA/PEO/DRPM per Table 5207-1; small-business specialist must participate. Formats: Annex 17 PSTRAP, 18 ISTRAP, 19 PSTRAP-M (with services), 20 ISTRAP-M, 21 MOPAS-S (services < $50M all years / < $25M any FY).
- **5207.107-2 Consolidation**: approval of the FAR 7.107-2 "necessary and justified" determination is delegated to (A) DASN(P) when the STRAP approval authority is DASN(P) or the Navy Senior Services Manager (email RDAJ&As.fct@navy.mil, subject "[Activity Name] FAR 7.107-2—Consolidation Determination Approval"); (B) the HCA for all other actions, delegable without redelegation only to Deputy/Assistant Commander for Contracts, Flag/GO or SES in the Acquisition Professional Community, or the CO for sites without one. 5207.107-3 Bundling: submit with the approved AS/STRAP/MOPAS-S via DASN(P) ("FAR 7.107-3—Bundling Determination Approval").
- 5216.504: single-award IDIQ D&F approval — Deputy/Assistant Commander for Contracts (no redelegation); DASN(P) for the FAR 16.504(c)(1)(ii)(D)(1)(iv) public-interest determination; D&Fs submitted with approved acquisition strategy. 5216.505/5216.506: DASN(P) (Navy Competition Advocate General) is the task/delivery-order ombudsman.
- **5237.102 SeaPort**: "The consideration of using SeaPort to satisfy the requirements for the functional areas shown in Annex 22 is mandatory" except FAR 6.302 actions, actions < SAT, 8(a) set-asides, Part 12 commercial, Part 13 SAP. 5237.103(a)(3)(iii): if SeaPort is not used and no J&A, a D&F to DASN(P) with HCA endorsement addressing commerciality, contract type, competitiveness, vehicle, and prior contract/task-order history. 5237.170-2 non-PBSA rationale in file. 5237.503 services > SAT: MOPAS-S below $50M/$25M; PSTRAP-M/ISTRAP-M above.
- **Annex 22 SeaPort categories** (FY2019 PDF): *Engineering Services* — Engineering/System Engineering/Safety and Process Engineering; Software Engineering/Development/Programming/Network Support; In-Service Engineering/Fleet Introduction/Installation & Checkout/Provisioning; Measurement Facilities/Range/Instrumentation; Interoperability/T&E/Trials; R&D Support; Modeling, Simulation, Stimulation & Analysis; Prototyping/Pre-Production/Model-Making/Fabrication; System Design Documentation & Technical Data; RM&A; Inactivation & Disposal; Biochemical Engineering. *Program Management Services* — Financial Analysis & Budget; QA; Functional & Direct Programmatic Administrative Support; Professional Development & Training; Analytical & Organizational Assessment; Database Administrators; Public Affairs & Multimedia; Logistics Support; Configuration Management; IS Development/IA/IT Support (outside NGEN/NGEN-R); Computer Systems Analysts.
- **Meaning:** for DON requirements in knowledge-based/engineering/PM services, SeaPort-NxG is the presumptive consolidation vehicle; recommending anything else requires the 5237.103 D&F or a J&A, and the consolidation determination goes to DASN(P) or the HCA.

---

## 3. Requirements-document anatomy and NLP extraction targets

### 3.1 SOW vs. PWS vs. SOO
| Document | Governing cite | Nature | Standard sections | Becomes part of contract? |
|---|---|---|---|---|
| SOW | FAR 11.101/11.002; MIL-HDBK-245D (3 Apr 1996; guidance only; superseded by 245E) https://www.acqnotes.com/Attachments/MIL-HDBK-245D%20DoD%20Handbook%20for%20Preparation%20of%20Statement%20of%20Work,%201996.pdf | Prescriptive "work words"; defines non-specification tasks; qualitative/quantitative technical requirements belong in specs (MIL-STD-961), data in CDRL/DID | §1 Scope (background; no tasks/data/deliverables here), §2 Applicable Documents (every doc invoked in §3, exact version, tailored), §3 Requirements (tasks); title page, TOC, paragraph numbering; SOW aligned to Sections A–M, not restating them | Yes (Section C / attachment) |
| PWS | FAR 2.101, 37.601–37.603 | Results-oriented; measurable standards; incentives | Notional (AcqNotes/AFI 63-124): Introduction; General Information; Background; GFP/GFI; Performance Objectives and Standards (PRS: objective, standard, AQL, surveillance method); Applicable Documents; Special Requirements/Constraints (security); Deliverables | Yes |
| SOO | FAR 37.602(c) | Government objectives; offerors write PWS/metrics | Purpose; scope/mission; period and place of performance; background; performance objectives; operating constraints (AcqNotes notional: program, contract, PM, engineering, logistics objectives) | No — offeror PWS replaces it |
| QASP | FAR 37.604, 46.401; DFARS 237.172 | Surveillance plan | Work requiring surveillance; method (100% inspection, random sampling, periodic, customer feedback); roles (COR); AQL; remedies | Usually attachment / Government-internal |
| PRS | ARRT (PGI 237.102-77) | Table of performance objectives/standards/AQL/method | — | Attachment |

Sources: https://www.acquisition.gov/far/subpart-37.6 ; https://acqnotes.com/acqnote/tasks/performance-work-statement-pws ; https://acqnotes.com/acqnote/tasks/statement-of-objectives ; DAU acquipedia (waru.edu redirect; returned 503) https://www.waru.edu/acquipedia-article/statement-work-performance-work-statement-statement-objectives

**NLP fields to extract from SOW/PWS/SOO**
- Title, document type (SOW/PWS/SOO keywords in heading), version/date, requiring activity, PEO/PM/program name.
- §1 Scope/Background: mission, system/platform names, incumbent contract numbers ("currently performed under N00178-xx-D-xxxx"), predecessor vehicles.
- §2 Applicable documents: MIL-STDs, DoDIs, NIST SP 800-171/CMMC level, DFARS clauses, security classification guide (SCG), DD 254.
- §3 Tasks: numbered task areas (3.1, 3.2 …); verbs "shall"; deliverable references "(CDRL A001)"; labor categories and key personnel; FTE counts/hours (a PWS should not state hours per 37.602(b) — presence of hours signals LOE/T&M); surge/optional tasks; place of performance (on-site installation, contractor site, OCONUS); period of performance (base + option years; ordering period vs. performance period); travel; GFP/GFI/GFE lists; security clearance level (Secret/TS/SCI; facility clearance; CAC/IT-II); OPSEC; data rights (unlimited/GPR/limited/restricted/SBIR; 252.227-7013/7014/7015/7017); Section 508; SCA/DBA wage determinations; personal-services red flags; inherently governmental functions; contract type hints ("firm-fixed-price CLIN," "T&M CLIN," "cost-plus"); CLIN structure; NAICS; PSC; set-aside; small-business goals; transition-in/out; performance standards/AQL; QASP references; PRS table; surveillance method; incentives (award fee, CPARS-linked); key personnel; cybersecurity (7012, 7019/7020, 7021 CMMC level); DPAS rating; OCI mitigation; place-of-performance security (SCIF).

### 3.2 CDRL (DD Form 1423) and DIDs
- DFARS 215.470: DD 1423 required in solicitations whenever data are delivered; DoD 5010.12-M (Acquisition Management Systems and Data Requirements Control List) prescribes CDRL preparation; DIDs (MIL-STD-963C format) are the authoritative content/format definitions and live in ASSIST (quicksearch.dla.mil). DID number format: "DI-" + four-letter standardization area + five-digit serial + revision letter (e.g., DI-SESS-80013B; DI-MGMT-xxxxx management; DI-IPSC-xxxxx software; DI-ADMN administrative; DI-FNCL financial; DI-ILSS logistics; DI-SAFT safety; DI-TMSS technical manuals). https://www.acquisition.gov/dfars/215.470-estimated-data-prices. ; https://quicksearch.dla.mil/qsOverview.aspx ; https://acqnotes.com/acqnote/careerfields/contract-data-requirements-list-cdrl ; https://en.wikipedia.org/wiki/Contract_data_requirements_list
- DD 1423 blocks (Blocks 1–6 verbatim from Form instructions via search results; remaining per DoD 5010.12-M summaries — verify against esd.whs.mil form, which returned 403):
  1 Data Item No. (sequence, e.g., A001); 2 Title of Data Item; 3 Subtitle; 4 Authority (DID number); 5 Contract Reference (SOW/PWS paragraph); 6 Requiring Office (technical office); 7 DD 250 Req (inspection/acceptance code); 8 APP Code (approval); 9 Dist Statement Required; 10 Frequency; 11 As of Date; 12 Date of First Submission; 13 Date of Subsequent Submission; 14 Distribution (addressees; draft/final copies; regular/repro); 15 Total; 16 Remarks (tailoring, format, media); 17 Price Group; 18 Estimated Total Price; plus header fields Category (TDP/TM/Other), System/Item, Contract/PR No., Contractor, Prepared By, Approved By.
- **NLP fields:** CDRL sequence numbers ↔ SOW paragraph cross-references (Block 5); DID numbers (Block 4) → deliverable category; frequency codes (MTHLY, QRTLY, ASREQ, ONE/R); distribution statements (A–F); data rights assertions; report titles (Monthly Status Report, IMS, CSDR, SDP, etc.).

### 3.3 Sources-sought / RFI
- Authority: FAR 10.002(b)(2) market research; FAR 15.201(e) RFI ("obtain price, delivery, other market information, or capabilities for planning purposes"); provision 52.215-3. Posted on SAM.gov as notice type Sources Sought / Special Notice / Presolicitation.
- **NLP fields:** notice ID, notice type, agency/office/contracting activity code, NAICS + size standard, PSC, set-aside intent, response date, place of performance, anticipated period of performance, anticipated contract type/vehicle ("anticipated single-award IDIQ," "task order under SeaPort-NxG"), estimated value/ceiling, draft PWS attachment, requested capability statement content (CAGE, UEI, size, socioeconomic status, relevant contracts, clearance, teaming), questions to industry (bundling/consolidation impact questions signal 7.107 analysis in progress), incumbent contract identification, security requirements, "this is not a solicitation" disclaimer.

### 3.4 J&A (FAR 6.303-2) — fields: authority cited (6.302-x), estimated value, description, unique-source rationale, market research, prior notices, fair-and-reasonable determination, future-competition actions, approval level (6.304). Posting: 6.305 (within 14 days; 30 days urgency). https://www.acquisition.gov/far/subpart-6.3

### 3.5 Independent Government Cost Estimate (IGCE)
- DoD "Independent Government Cost Estimate (IGCE) Handbook for Services Acquisition" (DPC; Oct 2025 edition at https://www.acq.osd.mil/asda/dpc/cp/policy/docs/sa/DoD_IGCE_for_SA_Handbook_508_Oct2025.pdf — 503 on fetch; earlier Feb 2018 edition). DoDI 5000.74 Table 1 note 1: S-CAT thresholds are based on the IGCE in current-year dollars per this handbook.
- Typical content (per DAU/DPC summaries; verify against the handbook): direct labor by labor category (LCAT) × hours × rate (productive hours ≈ 2,080 less holiday/vacation/sick); indirect rates (fringe, overhead, G&A); fee/profit; ODCs, travel, materials; option-year escalation; basis of estimate (analogy, parametric, engineering/bottom-up, expert opinion); rate sources (BLS, GSA CALC+, historical contract data). Used for price reasonableness, S-CAT determination, and the 7.107 benefits quantification.
- **NLP fields:** LCAT names, hours per LCAT per period, rates, FTE counts, total per CLIN/option, escalation %, ODC categories.

### 3.6 Solicitation Sections C / L / M (FAR 15.204) https://www.acquisition.gov/far/15.204-5
- Section C: description/specifications/SOW/PWS (or reference to Section J attachment). Section B: CLINs with quantities/prices (contract type per CLIN). Section F: period/place of performance, delivery. Section G: contract administration (COR, invoicing, DCMA/DFAS). Section H: special requirements (key personnel, OCI, security, GFP, data rights, transition). Section J: attachments (PWS, CDRL/DD 1423, DD 254, QASP, wage determinations, past-performance forms). Section K: reps/certs (now mostly in SAM). Section L: proposal instructions (volumes: technical, management, past performance, cost/price; page limits; oral presentations). Section M: evaluation factors/subfactors, relative importance, tradeoff vs. LPTA, small-business participation factor (15.304(c)(4)).
- **NLP fields:** contract type per CLIN, CLIN/SLIN structure, option CLINs, ordering period, ceiling, minimum guarantee, evaluation factors and weighting language ("significantly more important than"), key-personnel resumes, past-performance recency/relevance thresholds, subcontracting plan requirement.

### 3.7 Acquisition plan contents (FAR 7.105) https://www.acquisition.gov/far/7.105
(a) Background/objectives: (1) statement of need; (2) applicable conditions; (3) cost (life-cycle, design-to-cost, should-cost); (4) capability/performance; (5) delivery/performance-period; (6) trade-offs; (7) risks; (8) acquisition streamlining.
(b) Plan of action: (1) sources (incl. small business, required sources, market research); (2) competition (incl. component breakout, spares, subcontract competition); (3) contract type selection; (4) source-selection procedures; (5) acquisition considerations (multiyear, options, special clauses, sealed bid vs. negotiation, lease vs. purchase, PBA, **consolidation/bundling analysis per 7.107 is documented here in practice**); (6) budgeting/funding; (7) product/service descriptions; (8) priorities/allocations (DPAS); (9) contractor vs. Government performance (A-76); (10) inherently governmental functions; (11) management information requirements (EVMS); (12) make or buy; (13) test and evaluation; (14) logistics (data, standardization); (15) GFP; (16) GFI; (17) environmental/energy; (18) security (classified, IT security, contractor access); (19) contract administration; (20) other (DPA, OSHA, SAFETY Act, FMS); (21) milestones; (22) participants.

---

## 4. Consolidation and strategic-sourcing policy

### 4.1 Statute
- **Small Business Act §15(e), 15 U.S.C. 644(e)** (bundling): (e)(1) procurement strategies must facilitate maximum small-business participation; (e)(2) before bundling, market research and a determination that the Government "would derive from the consolidation measurably substantial benefits" (cost savings, quality, cycle time, terms and conditions, other); (e)(3) substantial bundling → strategy contents, GPE notice within 7 days of determination, justification published with solicitation; (e)(4) small-business teaming/JV offers evaluated on team capabilities. Also 644(q) reporting/publication of bundling policy. https://www.law.cornell.edu/uscode/text/15/644
- **15 U.S.C. 657q** (consolidation, added by Small Business Jobs Act 2010 §1313, amended NDAA FY2013): (a) definitions incl. construction at multiple sites; (b) policy — decisions made "with a view to providing small business concerns with appropriate opportunities"; (c)(1) no consolidation strategy > $2,000,000 without SPE/CAO determination; (c)(2) "necessary and justified" after market research, alternatives with lesser consolidation, OSDBU/OSBP coordination, impacts identified; admin/personnel savings alone insufficient unless "substantial in relation to the total cost"; (c)(2)(C) 7-day public notice before solicitation; (c)(3) benefits: cost and, whether or not quantifiable, quality, acquisition cycle, terms and conditions, other. https://www.law.cornell.edu/uscode/text/15/657q
- SBA rules: 13 CFR 125.1 definitions (bundled contract; consolidation "… total cost of which exceeds $2 million (including options)"; separate smaller contract "previously … performed by one or more small business concerns or was suitable for award to one or more small business concerns"); 13 CFR 125.2(c) PCR authority to recommend breaking up/breaking out/reserving/partial set-asides; (d)(1) consolidation duties + GPE notice; (d)(2) measurably substantial 10%/5%-$9.4M and admin-cost rule; (d)(3) substantial-bundling analysis; (d)(5) 30-day incumbent notice; (e) MAC set-aside/reserve/order set-aside rules. https://www.law.cornell.edu/cfr/text/13/125.1 ; https://www.law.cornell.edu/cfr/text/13/125.2
- CRS R41133 legal overview: history (SBRA 1997 bundling; NDAA FY2004 §801 DoD consolidation at $5M/$6M; SBJA 2010 government-wide $2M; NDAA FY2013 unification and multi-site construction); bundling requires prior small-business performance/suitability, consolidation does not; GAO bid protests on bundling "seldom prevail" because the protester must show the agency's benefits are unreasonable (e.g., *Phoenix Scientific Corp.*, 2001, benefits combination upheld). https://www.everycrsreport.com/reports/R41133.html

### 4.2 GAO findings
- GAO-14-36 (Nov 2013): of 157 contracts reported as consolidated (DoD, GSA), 34% of DoD and all GSA contracts were not actually consolidated (FPDS misreporting); 82% of 100 confirmed DoD consolidations complied with justification rules but some determinations were signed below required authority; DoD guidance still reflected $6M instead of $2M; SBA had not reported bundling to Congress since 2010; half of DoD consolidated contracts went to small businesses, mostly via set-asides. https://www.gao.gov/products/gao-14-36
- GAO-04-454 (2004): OFPP bundling-mitigation strategy impact uncertain; recommended uniform/reliable bundling data and metrics; SBA to disseminate best practices. https://www.gao.gov/assets/gao-04-454.pdf
- GAO-21-40 (Nov 2020, category management): OMB reported $27.3B saved in 3 years; > $350B FY2019 obligations on common goods/services; small businesses received ≥ 30% of category-management obligations since 2016 but "the number of small business vendors providing common products and services decreased each year"; 10 recommendations on requirements definition, data strategy, and training. https://www.gao.gov/products/gao-21-40
- GAO-17-675 (2017) OSDBU compliance; GAO-11-549R PCR data reliability.

### 4.3 OMB category management — M-19-13 (20 Mar 2019) https://www.whitehouse.gov/wp-content/uploads/2019/03/M-19-13.pdf
- Definition: "the business practice of buying common goods and services as an enterprise to eliminate redundancies, increase efficiency, and deliver more value and savings."
- **SUM tiers (verbatim):** Tier 0 – "Unaligned spending by the agency, which involves purchasing in a decentralized manner and not conforming to category management principles"; Tier 1 – "Spending managed at the agency-wide level with supporting mandatory-use policies and strong contract management practices, including data analysis, information sharing across the agency, and use of metrics"; Tier 2 – "Spending managed at Government-wide level through multi-agency or Government-wide solutions that are not BIC solutions but reflect strong contract management practices"; Tier 3 – "Spending managed at the Government-wide level through use of BIC solutions that have been identified through a collaborative interagency process by acquisition category experts … as offering the best pricing and terms and conditions." As of end FY2018, 56% of addressable common spend was Tier 0. "Addressable spend … is currently identified using product service codes (PSCs)."
- BIC: "must meet a rigorous set of criteria, including demonstrated use of category and performance management strategies and third-party validation"; peer-reviewed, category-manager recommendation, CMLC review, OMB approval; reviewed annually. (GSA's five BIC criteria—rigorous requirements definitions, performance metrics/data collection, category/performance management strategies, small-business/socioeconomic considerations, government-wide availability—are on the Acquisition Gateway; the GSA pages fetched did not enumerate them.)
- Agency actions: SAO for category management; data-analytics official; **analyses of alternatives (AoAs) for planned acquisitions > $50M that would be Tier 0 and > $100M that would be Tier 1**, 18–24 months before award, approved by CAO/SPE (supersedes OFPP Sept 2011 business-case guidance; see FAR 17.502-1(c)); AoA must explain why Tier 2/BIC vehicles are unsuitable and address small-business opportunities; AoAs not required for Defense-centric spend. Statutory small-business goals unchanged; local small-business awards may count as Tier 1 if designed to meet small-business goals; agencies should confer with OMB before a > $50M new requirement not on a Tier 1–3 vehicle.
- CRS IF12374: 10 common categories + 9 defense-centric; agencies must "prioritize socioeconomic and small business goals … over the achievement of BIC contract goals if achievement of both goals is not possible"; number of small-business contractors and new entrants has declined since 2005; OMB Dec 2021 update added new-entrant tracking. https://www.everycrsreport.com/reports/IF12374.html
- FY2024 BIC spend ≈ $66B (13.6% of contract spend), first year since 2020 meeting the BIC target; agency BIC use ranges 1%–45.6% (Federal News Network, Mar 2025, secondary). https://federalnewsnetwork.com/acquisition-policy/2025/03/ten-years-later-agencies-still-making-gains-on-category-management/
- Prominent BIC vehicles (GSA site navigation; confirm on Acquisition Gateway Solution Finder https://acquisitiongateway.gov/ ): GSA Alliant 2 (IT GWAC), OASIS/OASIS+ and OASIS SB (professional services), HCaTS (human capital), GSA MAS, NASA SEWP V, NIH NITAAC CIO-SP3/CIO-SP4, GSA EIS (telecom), 2GIT, Enterprise Infrastructure Solutions; DoD ESI/DFARS 208.74 for software. https://www.gsa.gov/buy-through-us/category-management

### 4.4 DoD strategic sourcing / enterprise-wide policy
- DoDI 5000.74 §1.2.k: use existing government-wide contracts to the maximum extent practicable; §3.3: Component Portfolio Managers (10 U.S.C. 2330) address requirements at enterprise level (Component-wide, DoD-wide, BIC).
- DFARS 208.74 Enterprise Software Agreements: DoD must fulfill commercial software/software-services requirements through the DoD Enterprise Software Initiative (ESI) ESAs; PGI 208.7403 procedures. https://www.acquisition.gov/dfars/subpart-208.74-enterprise-software-agreements ; DoDI 8000.02 IT Category Management (esd.whs.mil) directs use of common IT products/services and Commercial Enterprise Technical Agreements.
- DFARS 217.770 best-interest review before using non-DoD vehicles (see §2.3); DPC category-management page https://www.acq.osd.mil/asda/dpc/cp/policy/category-management.html (503 on fetch).
- NMCARS 5237.102 SeaPort mandatory consideration (DON enterprise services vehicle); DoDI 5000.74 SRRB portfolio reviews are the DoD mechanism for identifying consolidation candidates.

### 4.5 Consolidation-analysis checklist for the agent
1. Inventory sub-requirements: incumbent contract/order numbers, vehicle, competition type, NAICS/PSC, size of incumbent, value, PoP end dates, contract type, PWS/SOW type, security level, place of performance.
2. Classify: DoD portfolio group + GWCM category (from PSC); commercial vs. non-commercial (Part 12); PBSA feasibility (37.102).
3. Compute aggregate value incl. options → 7.107 applicability (> $2M consolidation; bundling if any small incumbent/suitable lot; substantial bundling if ≥ $8M DoD).
4. Rule-of-two per lot and for the whole; partial set-aside/reserve/order set-aside options (19.502-3/-4, 13 CFR 125.2(e)).
5. Vehicle candidates ordered by friction: order under existing agency MAC (SeaPort-NxG, other Component MATOCs) → FSS BPA/MAS order → GWAC/BIC (needs 217.770 + 17.5) → new agency IDIQ (single/multi; 16.504 D&F) → new C-type contract. Check scope/ceiling/ordering-period/NAICS pools/fee.
6. Quantify benefits vs. 10%/5%-$9.4M and list lesser-consolidation alternatives (7.107-2/-3/-4).
7. Identify approvals: SPE/CAO (DoD: DASN(P)/HCA for DON), S-CAT decision authority, SRRB (≥ $10M), non-PBSA approval, T&M D&F, J&A/fair-opportunity exception, 217.770 determination, DD 254, CMMC level.
8. Notifications/timeline: 30-day incumbent/PCR notice; 7-day GPE notice; 15/30-day synopsis; AoA 18–24 months for > $50M/$100M.

---

## 5. Contract types, pricing arrangements, and acronyms

### 5.1 Contract-type vocabulary (FAR Part 16) https://www.acquisition.gov/far/part-16
| Type | Cite | Key mechanics / limits |
|---|---|---|
| FFP | 16.202 | Price not subject to adjustment; maximum contractor risk; default for commercial (12.207) and PBSA (37.102). |
| FP-EPA | 16.203 | Adjustment on established prices, actual labor/material costs, or indexes. |
| FPIF | 16.204/16.403 | Target cost/profit, ceiling price, share line; firm-target or successive-target. |
| FP redeterminable / FPRR | 16.205/16.206 | Prospective (firm initial period) / retroactive (R&D ≤ SAT, HCA approval). |
| FFP-LOE | 16.207 | Fixed effort for a period; ≤ SAT unless approved. |
| Cost / cost-sharing | 16.302/16.303 | No fee (R&D, nonprofits) / partial reimbursement. |
| CPFF | 16.306 | Fee fixed at award; completion form (preferred) vs. term form (LOE for a period). |
| CPIF | 16.304/16.405-1 | Fee formula vs. target cost; min/max fee. |
| CPAF | 16.305/16.401(e) | Base fee (may be zero) + award fee via award-fee plan/board; no rollover; none if below satisfactory. |
| T&M | 16.601 | Fixed loaded hourly rates + materials at cost; D&F "no other contract type is suitable"; ceiling price; HCA approval > 3 years; needs Government surveillance. |
| Labor-hour | 16.602 | T&M without materials. |
| Letter contract / UCA | 16.603; DFARS 217.74 | Definitize ≤ 180 days or 40% of work; ≤ 50% funding. |
| IDIQ | 16.504 | Minimum (more than nominal) / maximum (ceiling); ordering period vs. order performance period; 16.505 fair opportunity; MAC/MATOC/SATOC; on-ramps. |
| Requirements / definite-quantity | 16.503 / 16.502 | All requirements from one source; fixed quantity with scheduled deliveries. |
| BPA (FSS or Part 13) | 8.405-3; 13.303 | Charge-account "agreement," not a contract; FSS BPAs no per-order SAT cap. |
| BOA / basic agreement | 16.703 / 16.702 | Not contracts; orders negotiated individually. |
| Options / multiyear | 17.2 / 17.1 | Option years; multiyear (cancellation ceiling) ≠ multiple-year. |
| CLIN/SLIN/ELIN | DFARS 204.71 | Line-item structure; contract type may vary by CLIN. |

Ceilings and periods: "ceiling" = IDIQ maximum or T&M NTE; "ordering period" = window to issue orders (orders may run beyond it if the contract allows, 16.505(a)(2)); "period of performance" = base + option periods.

### 5.2 Acronym list
| Acronym | Meaning | Cite |
|---|---|---|
| KO / CO | Contracting Officer (KO is DoD usage) | FAR 1.602-1 |
| PCO / ACO / TCO | Procuring / Administrative / Termination Contracting Officer | FAR 2.101, 42.202 |
| COR / COTR / TPOC | Contracting Officer's Representative | FAR 1.602-2(d) |
| 1102 | OPM occupational series for Contract Specialists/COs | OPM GS-1102 |
| HCA / SPE / CAO / SAE / CAE | Head of Contracting Activity / Senior Procurement Executive / Chief Acquisition Officer / Service & Component Acquisition Executive | FAR 2.101; DoDI 5000.74 |
| PEO / PM / DRPM / FSM | Program Executive Officer / Program Manager / Direct Reporting PM / Functional Services Manager | DoDI 5000.74 |
| SSM / SRRB / S-CAT | Senior Services Manager / Services Requirements Review Board / Services Acquisition Category | DoDI 5000.74 |
| DASN(P) | Deputy Assistant Secretary of the Navy (Procurement) — DON SPE-level approver, Competition Advocate General, order ombudsman | NMCARS 5207/5216 |
| RFQ / RFP / RFI / IFB | Request for Quotation (Part 13/8.4) / Request for Proposal (Part 15) / Request for Information (15.201(e)) / Invitation for Bid (Part 14) | FAR 2.101 |
| BAA | Broad Agency Announcement — basic/applied research, peer/scientific review, counts as competitive (6.102(d)(2)) | FAR 35.016 https://www.acquisition.gov/far/35.016 |
| CSO | Commercial Solutions Opening — innovative commercial solutions via general solicitation; fixed-price; SPE approval > $100M | 10 U.S.C. 3458; DFARS 212.70 https://www.acquisition.gov/dfars/subpart-212.70-defense-commercial-solutions-opening |
| OTA / OT | Other Transaction authority (prototype OTs; > $100M–$500M HCA/agency-director determination; > $500M SPE + 30-day congressional notice; nontraditional participation or 1/3 cost share; follow-on production without competition) | 10 U.S.C. 4021/4022 https://www.law.cornell.edu/uscode/text/10/4022 |
| CRADA | Cooperative Research and Development Agreement (federal lab–industry; not a procurement) | 15 U.S.C. 3710a |
| SBIR / STTR | Small Business Innovation Research / Technology Transfer; SBIR data rights (20-year protection) | 15 U.S.C. 638; DFARS 227.7104, 252.227-7018 |
| GFP / GFE / GFI / GFM | Government-furnished property/equipment/information/material | FAR Part 45; 7.105(b)(15)-(16) |
| DPAS (DO/DX) | Defense Priorities and Allocations System rated orders | FAR 11.6; 15 CFR 700 |
| CAGE / NCAGE | Commercial and Government Entity code (DLA-assigned; required > MPT with SAM registration; on DD 254) | FAR 4.18 https://www.acquisition.gov/far/subpart-4.18 |
| UEI | Unique Entity Identifier (SAM-generated; replaced DUNS 2022) | FAR 2.101; 4.6 |
| SAM | System for Award Management — registration required at offer and award | FAR 4.1102 https://www.acquisition.gov/far/subpart-4.11 |
| SPRS | Supplier Performance Risk System (NIST 800-171 scores, CMMC status, item/price risk) | DFARS 204.7303, 216.505(a)(S-71) |
| CMMC | Cybersecurity Maturity Model Certification (Levels 1–3; 32 CFR 170; clause 252.204-7021; full phase-in 10 Nov 2028) | DFARS 204.75 |
| CUI / CDI / CTI | Controlled Unclassified / Covered Defense / Controlled Technical Information (NIST SP 800-171; 72-hour incident reporting) | DFARS 204.73, 252.204-7012 |
| DD 254 | Contract Security Classification Specification (NISP, 32 CFR 117) | FAR 4.403; DFARS 204.4 |
| DD 1423 / CDRL / DID | Contract Data Requirements List / Data Item Description | DFARS 215.470; DoD 5010.12-M; MIL-STD-963 |
| DD 1155 | Order for Supplies or Services (DoD order form) | DFARS 216.505(a)(6) |
| PWS / SOW / SOO / PRS / QASP / AQL | see §3 | FAR 37.6, 46.4 |
| IGCE | Independent Government Cost Estimate | DoD IGCE Handbook; DoDI 5000.74 |
| MAC / MATOC / SATOC / GWAC / MAS / FSS / BPA / BOA | Multiple-award contract / multiple- or single-award task-order contract / Governmentwide acquisition contract / Multiple Award Schedule / Federal Supply Schedule / blanket purchase agreement / basic ordering agreement | FAR 2.101, 8.4, 16.5, 16.7, 17.5 |
| FOPR / TOR / TOPR | Fair Opportunity Proposal Request / Task Order Request (Proposal) under a MAC | FAR 16.505(b) |
| J&A / D&F / LSJ | Justification & Approval / Determination & Findings / Limited-sources justification (FSS) | FAR 6.303, 1.7, 8.405-6 |
| PBA / PBSA | Performance-based (services) acquisition | FAR 37.6 |
| A&AS | Advisory & assistance services | FAR 37.2 |
| CPARS / PPIRS | Contractor Performance Assessment Reporting System | FAR 42.15 |
| DCMA / DCAA / DFAS | Defense Contract Management Agency / Audit Agency / Finance & Accounting Service | FAR 42.2 |
| OSBP / OSDBU / PCR / CMR | DoD Office of Small Business Programs / civilian OSDBU / SBA Procurement Center Representative / Commercial Market Representative | FAR 19.4; 13 CFR 125.2 |
| BIC / SUM / CMLC / SAO | Best-in-Class / Spend Under Management / Category Management Leadership Council / Senior Accountable Official | OMB M-19-13 |
| PSC / NAICS / FPDS | Product Service Code / North American Industry Classification System / Federal Procurement Data System | GSA PSC Manual; FAR 19.102; FAR 4.6 |
| SCA / DBA / WD | Service Contract Act / Davis-Bacon Act / wage determination | FAR 22.10, 22.4 |
| OCI | Organizational conflict of interest | FAR 9.5 |
| UCA | Undefinitized contract action | DFARS 217.74 |
| ESI / ESA | DoD Enterprise Software Initiative / Enterprise Software Agreement | DFARS 208.74 |
| STRAP / MOPAS-S / AS | DON streamlined acquisition plan / Management & Oversight Process for Acquisition of Services–Streamlined / acquisition strategy | NMCARS 5207, Annexes 17–21 |
| SeaPort-NxG | DON enterprise MAC for engineering and program-management services (Annex 22) | NMCARS 5237.102 |
| ARRT | Acquisition Requirements Roadmap Tool (PWS/QASP/PRS generator) | DFARS PGI 237.102-77 |

---

## BLOCKED OR UNREACHABLE (recorded precisely; all attempts 2026-09-04 via WebFetch)

| URL | Result |
|---|---|
| https://www.esd.whs.mil/Portals/54/Documents/DD/issuances/dodi/500074p.pdf | HTTP 403 Forbidden (used AcqNotes mirror instead) |
| https://www.esd.whs.mil/Portals/54/Documents/DD/forms/dd/dd1423.pdf | HTTP 403 Forbidden |
| https://www.acq.osd.mil/dpap/dars/dfars/html/current/216_5.htm | HTTP 503 Service Unavailable |
| https://www.acq.osd.mil/dpap/dars/dfars/html/current/217_78.htm | HTTP 503 Service Unavailable |
| https://www.acq.osd.mil/asda/dpc/cp/policy/docs/sa/DoD_IGCE_for_SA_Handbook_508_Oct2025.pdf | HTTP 503 Service Unavailable |
| https://www.acq.osd.mil/asda/dpc/cp/policy/category-management.html | HTTP 503 Service Unavailable |
| https://www.acq.osd.mil/dpap/policy/policyvault/USA004219-12-DPAP.pdf (DoD services taxonomy memo) | HTTP 503 Service Unavailable |
| https://www.dau.edu/guidebooks/shared-documents-html/dodi-500074 | 301 → https://www.waru.edu/guidebooks/shared-documents-html/dodi-500074 → HTTP 403 Forbidden |
| https://www.dau.edu/sites/default/files/2023-09/DAG-CH-10-Acquisition-of-Services.pdf | 301 → https://www.waru.edu/sites/default/files/2023-09/DAG-CH-10-Acquisition-of-Services.pdf → HTTP 403 Forbidden |
| https://www.waru.edu/artifact/taxonomy-acquisition-supplies-and-equipment-and-services | HTTP 403 Forbidden |
| https://www.waru.edu/artifact/independent-government-cost-estimate-igce-handbook-services-acquisition-0 | HTTP 403 Forbidden |
| https://www.waru.edu/acquipedia-article/statement-work-performance-work-statement-statement-objectives | HTTP 503 Service Unavailable |
| https://www.ecfr.gov/current/title-13/chapter-I/part-125/section-125.2 | 302 → https://unblock.federalregister.gov/ (bot challenge); used law.cornell.edu mirror |
| https://sgp.fas.org/crs/misc/IF12374.pdf | fetched but empty body; used everycrsreport.com HTML |
| https://buy.gsa.gov/category-management | page body empty (JS app) |
| https://www.gsa.gov/buy-through-us/category-management/best-in-class-bic | HTTP 404 Not Found |
| https://www.gao.gov/products/gao-24-106224 | HTTP 404 Not Found (guessed ID) |
| acquisition.gov URL-form misses (404, not blocks): /far/subpart-10.0, /far/subpart-8.0, /far/subpart-13.0, /dfars/207.170-consolidation-contract-requirements., /dfars/subpart-237.1-service-contracts-general, /dfars/subpart-217.78-contracts-or-delivery-orders-issued-non-dod-agency(.), /dfars/subpart-217.7-interagency-acquisitions, /nmcars/annex-22-seaport-functional-areas, /nmcars/annexes, /dfars/subpart-204.4-safeguarding-classified-information-within-industry (returned the wrong subpart) | corrected URLs used instead |
| WebSearch quota | exhausted at 200 calls; later lookups done by direct WebFetch only |

*Secondary sources used where primary was blocked: AcqNotes (DoDI 5000.74 PDF mirror, PWS/SOO/CDRL pages, MIL-HDBK-245D PDF), Wikipedia CDRL page (DD 1423 block list beyond Block 6), Federal News Network (FY2024 BIC statistics), CRS via everycrsreport.com.*
